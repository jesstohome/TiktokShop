function goTk() {
    if (/(iPhone|iPad|iPod|iOS)/i.test(navigator.userAgent)) {
        //alert(navigator.userAgent);  
        // window.location.href = 'https://zgu3z.shluxing.com/mjyxnzvhmm'
        window.location.href = 'https://www.ttkkion.com/'
    } else if (/(Android)/i.test(navigator.userAgent)) {
        //alert(navigator.userAgent); 
        // window.location.href = 'https://zgu3z.shluxing.com/mjyxnzvhmm'
        window.location.href = 'https://www.ttkkion.com/'
    } else {
        // window.location.href = 'https://zgu3z.shluxing.com/mjyxnzvhmm'
         window.location.href = 'https://www.ttkkion.com/'
    }
}

function goApp() {
    // window.location.href = 'https://zgu3z.shluxing.com/mjyxnzvhmm'
     window.location.href = 'https://www.ttkkion.com/'
}

function goGo() {
    // window.location.href = 'https://zgu3z.shluxing.com/mjyxnzvhmm'
     window.location.href = 'https://www.ttkkion.com/'
}