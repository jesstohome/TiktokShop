<?php

return [
    'Id'         => '广告ID',
    'Name'       => '广告名称',
    'Price'      => '价格',
    'Time'       => '时长(秒)',
    'Type'       => '广告类型',
    'Type 1'     => '橱窗广告',
    'Type 2'     => '商品广告',
    'Click'      => '带来点击',
    'Sales'      => '带来销量',
    'Createtime' => '创建时间'
];
