<?php

return [
    'Title'         => '任务标题',
    'Crontab_id'    => '定时任务ID',
    'Success'       => '成功',
    'Failure'       => '失败',
    'Processid'     => '进程ID',
    'Inprogress'    => '执行中',
    'Content'       => '返回结果',
    'Result'        => '执行结果',
    'Complete time' => '完成时间',
    'Execute time'  => '最后执行时间',
];
