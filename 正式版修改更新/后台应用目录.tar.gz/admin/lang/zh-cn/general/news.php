<?php

return [
    'Id'         => 'id',
    'Title'      => '标题',
    'Content'    => '内容',
    'Status'     => '状态',
    'Status 0'   => '隐藏',
    'Set status to 0'=> '设为隐藏',
    'Status 1'   => '显示',
    'Set status to 1'=> '设为显示',
    'Createtime' => '创建时间'
];
