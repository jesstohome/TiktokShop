<?php

return [
    'Country'       => '国家',
    'Price'         => '价格',
    'National_flag' => '国旗',
    'Coin_name'     => '币种名称',
    'Coin_sign'     => '币种符号',
    'Exchange_min'  => '最小兑换',
    'Exchange_max'  => '最大兑换',
    'Status'        => '状态',
    'Status 0'      => '隐藏',
    'Set status to 0'=> '设为隐藏',
    'Status 1'      => '显示',
    'Set status to 1'=> '设为显示',
    'Createtime'    => '创建时间'
];
