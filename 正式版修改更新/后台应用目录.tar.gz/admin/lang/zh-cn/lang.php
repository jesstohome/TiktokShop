<?php

return [
    'Id'            => 'ID',
    'Language_name' => '语言名称',
    'Chinese_name'  => '语言名称(中文)',
    'File_name'     => '配置文件名称',
    'Status'        => '状态',
    'Status 1'      => '启用',
    'Status 0'      => '禁用',
    'Is_default'    => '默认语言',
    'Is_default 1'    => '是',
    'Is_default 0'    => '否',
    'Createtime'    => '创建时间'
];
