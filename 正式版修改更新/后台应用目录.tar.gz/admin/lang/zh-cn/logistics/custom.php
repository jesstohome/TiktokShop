<?php

return [
    'Id'         => 'ID',
    'Name'       => '名称',
    'Status'     => '状态',
    'Status 0'   => '禁用',
    'Set status to 0'=> '设为禁用',
    'Status 1'   => '启用',
    'Set status to 1'=> '设为启用',
    'Configure'  => '配置',
    'Createtime' => '创建时间'
];
