<?php

return [
    'Id'       => 'ID',
    'Step'     => '执行步骤',
    'Status'   => '执行状态',

    'Status 0' => '已暂停',
    'Set status to 0'=> '设为已暂停',
    'Status 1' => '正常',
    'Set status to 1'=> '设为正常',
    'Status 2' => '已执行',
    'Set status to 2'=> '设为已执行',
    'Status 3' => '已完成',
    'Set status to 3'=> '设为已完成',
    'Interval' => '时间间隔',
    'Mark'     => '描述'
];
