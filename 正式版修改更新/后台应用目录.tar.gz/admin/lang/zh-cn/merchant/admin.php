<?php

return [
    'Mer_admin_id'      => '商户管理员表ID',
    'Mer_id'            => '商户ID(属于哪一个商户)',
    'Account'           => '商户管理员账号',
    'Pwd'               => '商户管理员密码',
    'Real_name'         => '商户管理员姓名',
    'Phone'             => '商户管理员手机号',
    'Last_ip'           => '商户管理员最后一次登录IP地址',
    'Last_time'         => '商户管理员最后一次登录时间',
    'Status'            => '是否有效',
    'Status 1'          => '有效',
    'Set status to 1'   => '设为有效',
    'Status 0'          => '无效 ',
    'Set status to 0'   => '设为无效 ',
    'Createtime'        => '创建时间',
    'Merchant.mer_id'   => '商户id',
    'Merchant.mer_name' => '商户名称'
];
