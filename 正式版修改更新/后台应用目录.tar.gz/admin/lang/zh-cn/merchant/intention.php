<?php

return [
    'Mer_intention_id'  => 'ID',
    'User_id'           => '申请人ID',
    'Phone'             => '手机号',
    'Mer_name'          => '商户名称',
    'Name'              => '申请人',
    'Status'            => '处理状态',
    'Status 0'          => '待审核',
    'Set status to 0'   => '设为待审核',
    'Status 1'          => '通过',
    'Set status to 1'   => '设为通过',
    'Status 2'          => '未通过',
    'Set status to 2'   => '设为未通过',
    'Createtime'        => '创建时间',
    'Fail_msg'          => '未通过原因',
    'Mark'              => '备注',
    'Mer_id'            => '商户ID',
    'Images'            => '商户资质',
    'Mer_type_id'       => '店铺类型',
    'User.username'     => '用户名',
    'Merchant.mer_name' => '商户名称',
    'Type.type_name'    => '类型名称'
];
