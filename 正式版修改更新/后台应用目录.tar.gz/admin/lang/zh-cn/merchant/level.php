<?php

return [
    'Level_id'    => 'ID',
    'Name'        => '等级名称',
    'Name_en'     => '英文名称',
    'Product_num' => '商品数量',
    'Rate'        => '利润率',
    'Price'       => '升级价格',
    'Createtime'  => '创建时间',
    'Status'      => '状态',
    'Status 0'    => '关闭',
    'Set status to 0'=> '设为关闭',
    'Status 1'    => '开启',
    'Set status to 1'=> '设为开启'
];
