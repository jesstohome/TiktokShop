<?php

return [
    'Id'                => 'ID',
    'Mer_id'            => '接收消息的商户id',
    'Type'              => '消息类型',
    'Type 1'            => '系统消息',
    'Type 2'            => '用户通知',
    'User'              => '发送人',
    'Title'             => '消息标题',
    'Content'           => '消息内容',
    'Createtime'        => '消息发送时间',
    'Is_see'            => '查看状态',
    'Is_see 0'          => '未查看',
    'Is_see 1'          => '已查看',
    'See_time'          => '查看时间',
    'Merchant.mer_id'   => '商户id',
    'Merchant.mer_name' => '商户名称'
];
