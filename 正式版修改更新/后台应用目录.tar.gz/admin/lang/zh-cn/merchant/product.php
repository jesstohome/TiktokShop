<?php

return [
    'Id'                  => '橱窗ID',
    'Mer_id'              => '商户ID',
    'Product_id'          => '商品ID',
    'Sales'               => '销量',
    'Click'               => '点击量',
    'Predict_sales'       => '预计销量',
    'Predict_click'       => '预计点击量',
    'Is_ad'               => '是否广告中',
    'Is_ad 0'             => '否',
    'Is_ad 1'             => '是',
    'Ad_end_time'         => '广告结束时间',
    'Weigh'               => '权重',
    'Switch'              => '是否上架',
    'Switch 0'            => '否',
    'Switch 1'            => '是',
    'Updatetime'          => '更新时间',
    'Createtime'          => '创建时间',
    'Merchant.mer_id'     => '商户id',
    'Merchant.mer_name'   => '商户名称',
    'Product.product_id'  => '商品ID',
    'Product.title'       => '商品名称',
    'Product.image'       => '展示图',
    'Product.sales_price' => '销售价',
    'Product.cost_price'  => '成本价'
];
