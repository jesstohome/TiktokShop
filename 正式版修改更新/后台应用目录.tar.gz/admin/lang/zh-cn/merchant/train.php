<?php

return [
    'Id'         => 'ID',
    'Name'       => '推广名',
    'Hour'       => '小时数',
    'Order_num'  => '订单数',
    'Createtime' => '创建时间'
];
