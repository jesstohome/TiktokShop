<?php

return [
    'Mer_type_id' => '商户类型 id',
    'Type_name'   => '类型名称',
    'Type_info'   => '类型要求',
    'Description' => '类型说明',
    'Margin'      => '保证金',
    'Is_margin'   => '是否有保证金（0无,1有）',
    'Mark'        => '备注',
    'Createtime'  => '创建时间',
    'Updatetime'  => '更新时间'
];
