<?php

return [
    'Network'    => '网络名',
    'Blockchain' => '区块链地址',
    'Status'     => '状态',
    'Status 1'   => '开启',
    'Set status to 1'=> '设为开启',
    'Status 0'   => '关闭',
    'Set status to 0'=> '设为关闭',
    'Createtime' => '创建时间'
];
