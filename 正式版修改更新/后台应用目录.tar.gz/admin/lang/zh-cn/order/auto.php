<?php

return [
    'Id'         => 'id',
    'Mer_id'     => '商户',
    'User_id'    => '用户',
    'Product_id' => '商品',
    'Num'        => '执行数量',
    'Start_time' => '开始时间',
    'Status'     => '状态',
    'Status 0'   => '待执行',
    'Status 1'   => '执行中',
    'Status 2'   => '已完成',
    'Createtime' => '创建时间',
    'Updatetime' => '更新时间'
];
