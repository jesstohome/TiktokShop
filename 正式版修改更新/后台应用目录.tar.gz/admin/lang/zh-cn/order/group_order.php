<?php

return [
    'Group_order_sn'  => '订单号',
    'User_id'         => '用户 ID',
    'Total_postage'   => '邮费',
    'Total_price'     => '订单总额',
    'Total_num'       => '商品数',
    'Integral'        => '使用积分数量',
    'Integral_price'  => '积分抵扣金额',
    'Give_integral'   => '赠送积分',
    'Coupon_price'    => '优惠金额',
    'Pay_price'       => '支付金额',
    'Pay_postage'     => '支付邮费',
    'Cost'            => '成本价',
    'Coupon_id'       => ' 平台优惠券',
    'Give_coupon_ids' => '赠送优惠券',
    'Paid'            => '是否支付',
    'Pay_time'        => '支付时间',
    'Pay_type'        => '支付方式',
    'Pay_type 0'      => '余额',
    'Pay_type 1'      => '微信',
    'Pay_type 2'      => '小程序',
    'Pay_type 3'      => 'h5',
    'Createtime'      => '创建时间',
    'Is_combine'      => '是否为合并支付 '
];
