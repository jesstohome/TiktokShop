<?php

return [
    'Category_id'       => '商品分类ID',
    'Pid'               => '父id',
    'Name'              => '分类名称',
    'Name_en'           => '分类英文名称',
    'Path'              => '路径',
    'Pic'               => '图标',
    'Is_show'           => '是否显示',
    'Is_show 0'         => '否',
    'Is_show 1'         => '是',
    'Level'             => '等级',
    'Mer_id'            => '商户id',
    'Weigh'             => '权重',
    'Createtime'        => '创建时间',
    'Merchant.mer_name' => '所属商户'
];
