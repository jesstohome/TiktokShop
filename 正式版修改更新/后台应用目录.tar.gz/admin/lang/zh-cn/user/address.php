<?php

return [
    'User_id'     => '用户id',
    'Name'        => '名字',
    'Mobile'      => '电话',
    'Detail'      => '详细地址',
    'Province_id' => '省id',
    'City_id'     => '市id',
    'Area_id'     => '地区id',
    'Tag'         => '标签词',
    'Is_default'  => '是否为默认地址',
    'Createtime'  => '创建时间',
    'Updatetime'  => '更新时间'
];
