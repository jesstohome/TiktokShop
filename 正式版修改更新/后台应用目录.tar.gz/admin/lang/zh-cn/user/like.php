<?php

return [
    'User_id'    => '用户id',
    'Mer_id'     => '商户id',
    'Product_id' => '商品id',
    'Status'     => '状态',
    'Status 0'   => '取消',
    'Set status to 0'=> '设为取消',
    'Status 1'   => '已关注',
    'Set status to 1'=> '设为已关注',
    'Createtime' => '创建时间',
    'Updatetime' => '更新时间'
];
