<?php

namespace app\admin\model;

use think\Model;

class AuthGroupAccess extends Model
{
    //
}
