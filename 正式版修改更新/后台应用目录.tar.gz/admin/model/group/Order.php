<?php

namespace app\admin\model\group;

use think\Model;

class Order extends Model
{
    // 表名
    protected $name = 'group_order';
    
}
