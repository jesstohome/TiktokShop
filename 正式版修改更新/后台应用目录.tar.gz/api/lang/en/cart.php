<?php

return [
    '请求成功'                                                     => 'Request for success',
    '参数错误'                                                     => 'Parameter Error',
    '通知不存在'                                                    => 'Notice does not exist',
    '未找到该直通车'                                                => 'The through-train was not found',
    '余额不足，请先充值'                                              => 'Insufficient balance, please recharge first',
    '商户未铺货任何商品，无法自动下单'                                  => 'The merchant has not stocked any products, so automatic ordering is not possible',
    '购买失败'                                  => 'Purchase failed',
    '购买成功'                                  => 'Purchase success',
    '直通车购买记录'                                  => 'Through-train purchase record',
    '删除成功'                                  => 'Deletion successful',
    '修改成功'                                  => 'Modified successfully',
    '产品不存在或已下架'                          => 'Product does not exist or has been taken offline',
    '库存不足'                                  => 'Insufficient stock',
    '添加成功'                                  => 'Addition successful',
    '添加失败'                                  => 'Addition failed',


];
