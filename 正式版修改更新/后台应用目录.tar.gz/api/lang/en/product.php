<?php

return [
    '请求成功'                                                     => 'Request for success',
    '参数错误'                                                     => 'Parameter Error',
    '余额不足，请先充值'                                              => 'Insufficient balance, please recharge first',
    '购买失败'                                  => 'Purchase Failed',
    '购买成功'                                  => 'Purchase Successful',
    '操作成功'                                  => 'Operation successful',




];
