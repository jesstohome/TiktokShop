<?php

return [
    '请求成功' => 'Yêu cầu thành công',
'参数错误' => 'Lỗi tham số',
'通知不存在' => 'Thông báo không tồn tại',
'未找到该直通车' => 'Không tìm thấy chuyến xe trực tiếp này',
'余额不足，请先充值' => 'Số dư không đủ, vui lòng nạp tiền trước',
'商户未铺货任何商品，无法自动下单' => 'Người bán chưa nhập hàng bất kỳ sản phẩm nào, không thể đặt hàng tự động',
'购买失败' => 'Mua hàng thất bại',
'购买成功' => 'Mua hàng thành công',
'直通车购买记录' => 'Lịch sử mua vé thông hành',
'删除成功' => 'Xóa thành công',
'修改成功' => 'Chỉnh sửa thành công',
'产品不存在或已下架' => 'Sản phẩm không tồn tại hoặc đã ngừng bán',
'库存不足' => 'Hàng trong kho không đủ',
'添加成功' => 'Thêm thành công',
'添加失败' => 'Thêm thất bại',


];
