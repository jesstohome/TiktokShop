<?php

return [
    '请求成功' => 'Yêu cầu thành công',
'参数错误' => 'Lỗi tham số',
'余额不足，请先充值' => 'Số dư không đủ, vui lòng nạp tiền trước',
'购买失败' => 'Mua hàng thất bại',
'购买成功' => 'Mua hàng thành công',
'操作成功' => 'Thao tác thành công',




];
