<?php
/**
 * @copyright ©2020 AI在线客服系统
 * Created by PhpStorm.
 * User: Andy - Wangjie
 * Date: 2020/5/9
 * Time: 10:04
 */

namespace app\admin\model;

use think\Model;

class CommentSetting extends Model
{
    protected $table = 'wolive_comment_setting';

}