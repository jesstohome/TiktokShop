<?php
/**
 * Created by PhpStorm.
 * User: Andy
 * Date: 2020/4/10
 * Time: 15:26
 */

namespace app\service\model;

use think\Model;

class Visiter extends Model
{
    protected $table = 'wolive_visiter';
    protected $autoWriteTimestamp = false;
    
}