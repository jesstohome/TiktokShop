-- MySQL dump 10.13  Distrib 5.7.44, for Linux (x86_64)
--
-- Host: localhost    Database: kefu_wholesaleti
-- ------------------------------------------------------
-- Server version	5.7.44-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `wolive_admin`
--

DROP TABLE IF EXISTS `wolive_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wolive_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `addtime` int(11) NOT NULL DEFAULT '0',
  `is_delete` smallint(6) NOT NULL DEFAULT '0',
  `app_max_count` int(11) NOT NULL DEFAULT '0',
  `permission` longtext,
  `remark` varchar(255) NOT NULL DEFAULT '',
  `expire_time` int(11) NOT NULL DEFAULT '0' COMMENT '账户有效期至，0表示永久',
  `mobile` varchar(255) NOT NULL DEFAULT '' COMMENT '手机号',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wolive_admin`
--

LOCK TABLES `wolive_admin` WRITE;
/*!40000 ALTER TABLE `wolive_admin` DISABLE KEYS */;
INSERT INTO `wolive_admin` VALUES (1,'admin','c7122a1349c22cb3c009da3613d242ab',0,0,0,NULL,'',0,'');
/*!40000 ALTER TABLE `wolive_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wolive_admin_log`
--

DROP TABLE IF EXISTS `wolive_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wolive_admin_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `uid` int(11) DEFAULT NULL COMMENT '管理员ID',
  `info` text COMMENT '操作结果',
  `ip` varchar(20) NOT NULL DEFAULT '' COMMENT '操作IP',
  `user_agent` text NOT NULL COMMENT 'User-Agent',
  `create_time` int(11) DEFAULT NULL COMMENT '操作时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=333 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='管理员登录日志';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wolive_admin_log`
--

LOCK TABLES `wolive_admin_log` WRITE;
/*!40000 ALTER TABLE `wolive_admin_log` DISABLE KEYS */;
INSERT INTO `wolive_admin_log` VALUES (1,1,'登录成功','138.199.25.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36',1757236726),(2,1,'登录成功','138.199.25.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36',1757238616),(3,2,'登录成功','138.199.25.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36',1757245697),(4,1,'登录成功','138.199.25.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36',1757254764),(5,3,'Login successful','138.199.25.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36',1757254916),(6,3,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757254952),(7,3,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757254981),(8,3,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757255247),(9,1,'登录成功','103.169.127.202','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36',1757256885),(10,1,'登录成功','138.199.25.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36',1757257195),(11,3,'登录成功','138.199.25.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36',1757257286),(12,1,'登录成功','138.199.25.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36',1757257493),(13,4,'登录成功','138.199.25.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36',1757257627),(14,3,'Login successful','103.169.127.202','Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1',1757257885),(15,1,'登录成功','138.199.25.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36',1757258293),(16,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757258697),(17,0,'登录失败','103.169.127.202','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36',1757259067),(18,1,'登录成功','138.199.25.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36',1757259549),(19,5,'Login successful','103.169.127.202','Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1',1757260868),(20,3,'Login successful','150.228.148.150','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6.2 Mobile/22G100 Safari/604.1',1757305029),(21,3,'Login successful','150.228.148.150','Telegram/29601 CFNetwork/3826.600.41 Darwin/24.6.0',1757305029),(22,3,'Login successful','129.224.203.112','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6.2 Mobile/22G100 Safari/604.1',1757474024),(23,3,'Login successful','129.224.203.112','Telegram/29601 CFNetwork/3826.600.41 Darwin/24.6.0',1757474025),(24,3,'Login successful','65.18.124.122','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6.2 Mobile/22G100 Safari/604.1',1757560489),(25,3,'Login successful','65.18.124.122','Telegram/29601 CFNetwork/3826.600.41 Darwin/24.6.0',1757560490),(26,3,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757827545),(27,3,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757827555),(28,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757835159),(29,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757835169),(30,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757841307),(31,5,'Login successful','138.199.25.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36',1757841470),(32,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757846803),(33,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757846848),(34,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757846854),(35,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757846866),(36,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757846879),(37,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757846986),(38,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757846994),(39,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757847003),(40,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757847438),(41,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757847443),(42,5,'Login successful','138.199.25.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36',1757847565),(43,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757848072),(44,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757848089),(45,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757848129),(46,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757848143),(47,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757848157),(48,5,'Login successful','138.199.25.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36',1757853746),(49,5,'Login successful','138.199.25.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36',1757853772),(50,5,'Login successful','138.199.25.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36',1757853785),(51,5,'登录成功','138.199.25.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36',1757854112),(52,5,'登录成功','138.199.25.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36',1757854173),(53,5,'登录成功','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757854499),(54,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757854583),(55,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757854865),(56,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757855084),(57,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757855131),(58,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757855309),(59,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757855681),(60,5,'Login successful','138.199.25.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36',1757856086),(61,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757865575),(62,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757865592),(63,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757865638),(64,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757865807),(65,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757865862),(66,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757865961),(67,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757866012),(68,5,'Login successful','138.199.25.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36',1757866074),(69,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757866285),(70,5,'Login successful','138.199.25.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36',1757866403),(71,5,'Login successful','138.199.25.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36',1757866421),(72,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757866615),(73,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757867088),(74,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757867366),(75,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757867595),(76,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757867708),(77,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757867815),(78,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757867825),(79,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757902890),(80,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757902892),(81,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757902909),(82,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757903436),(83,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757903440),(84,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757903478),(85,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757903499),(86,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757903590),(87,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757903752),(88,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757904380),(89,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757904384),(90,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757904456),(91,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757904530),(92,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757904722),(93,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757904908),(94,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757904911),(95,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757904926),(96,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757904929),(97,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757904966),(98,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757904970),(99,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757904973),(100,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757905016),(101,1,'登录成功','138.199.25.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36',1757918753),(102,3,'Login successful','129.224.202.26','Mozilla/5.0 (iPhone; CPU iPhone OS 18_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1 Mobile/22B83 Safari/604.1',1757923277),(103,1,'登录成功','138.199.25.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36',1757924370),(104,6,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757932636),(105,6,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757932715),(106,1,'登录成功','138.199.25.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36',1757933333),(107,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757933393),(108,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1757933433),(109,3,'Login successful','129.224.202.150','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6.2 Mobile/22G100 Safari/604.1',1757989684),(110,3,'Login successful','129.224.202.150','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6.2 Mobile/22G100 Safari/604.1',1757989703),(111,3,'Login successful','129.224.202.150','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6.2 Mobile/22G100 Safari/604.1',1757989741),(112,3,'Login successful','129.224.202.150','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6.2 Mobile/22G100 Safari/604.1',1757989749),(113,1,'登录成功','138.199.25.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36',1757999224),(114,1,'登录成功','150.228.149.149','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36',1758012396),(115,0,'登录失败','150.228.149.149','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36',1758031817),(116,0,'登录失败','150.228.149.149','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36',1758031828),(117,0,'登录失败','150.228.149.149','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36',1758031852),(118,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1758033929),(119,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1758036559),(120,7,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6.2 Mobile/22G100 Safari/604.1',1758249721),(121,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1758268517),(122,7,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6.2 Mobile/22G100 Safari/604.1',1758275428),(123,8,'Login successful','150.228.149.196','Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1',1758283300),(124,8,'Login successful','150.228.149.196','Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1',1758283322),(125,7,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6.2 Mobile/22G100 Safari/604.1',1758284849),(126,7,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6.2 Mobile/22G100 Safari/604.1',1758285518),(127,9,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0 Mobile/23A341 Safari/604.1',1758287459),(128,10,'Login successful','150.228.149.196','Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1',1758289149),(129,11,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6.2 Mobile/22G100 Safari/604.1',1758289291),(130,11,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6.2 Mobile/22G100 Safari/604.1',1758289332),(131,11,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6.2 Mobile/22G100 Safari/604.1',1758289337),(132,10,'Login successful','150.228.149.196','Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1',1758289455),(133,11,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6.2 Mobile/22G100 Safari/604.1',1758289594),(134,7,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6.2 Mobile/22G100 Safari/604.1',1758290946),(135,10,'Login successful','150.228.149.196','Mozilla/5.0 (iPhone; CPU iPhone OS 16_3_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148-native_iOS-360123456789101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899100',1758303791),(136,11,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148-native_iOS-360123456789101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899100',1758306473),(137,11,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148-native_iOS-360123456789101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899100',1758335666),(138,1,'登录成功','138.199.25.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36',1758353945),(139,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1758357654),(140,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1758357680),(141,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1758357871),(142,5,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1758358024),(143,10,'Login successful','129.224.203.142','Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1',1758358545),(144,10,'Login successful','129.224.203.142','Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1',1758358555),(145,10,'Login successful','129.224.203.142','Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1',1758362352),(146,11,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1758399703),(147,12,'Login successful','65.18.124.29','Mozilla/5.0 (iPhone; CPU iPhone OS 16_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1',1758514376),(148,12,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 16_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1',1758524988),(149,12,'Login successful','150.228.148.120','Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1',1758544444),(150,13,'Login successful','150.228.148.120','Mozilla/5.0 (iPhone; CPU iPhone OS 18_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1 Mobile/15E148 Safari/604.1',1758555953),(151,13,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1 Mobile/15E148 Safari/604.1',1758556204),(152,8,'Login successful','129.224.202.247','Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1',1758557299),(153,12,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1',1758558515),(154,12,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 16_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1',1758599336),(155,12,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 16_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1',1758599345),(156,11,'Login successful','138.199.25.98','Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',1758624365),(157,9,'Login successful','150.228.149.103','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0 Mobile/15E148 Safari/604.1',1758626409),(158,9,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0 Mobile/15E148 Safari/604.1',1758630579),(159,9,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0 Mobile/15E148 Safari/604.1',1758711660),(160,9,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0 Mobile/15E148 Safari/604.1',1758713087),(161,9,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0 Mobile/15E148 Safari/604.1',1758713094),(162,9,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0 Mobile/15E148 Safari/604.1',1758713184),(163,9,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0 Mobile/15E148 Safari/604.1',1758713252),(164,9,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0 Mobile/15E148 Safari/604.1',1758713448),(165,0,'登录失败','138.199.25.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36',1758715655),(166,1,'登录成功','138.199.25.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36',1758715921),(167,5,'登录成功','138.199.25.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36',1758716029),(168,5,'登录成功','138.199.25.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36',1758716503),(169,1,'登录成功','129.224.203.177','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36',1758718500),(170,12,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 16_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1',1758771676),(171,12,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 16_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1',1758771683),(172,12,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 16_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1',1758771712),(173,13,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1 Mobile/15E148 Safari/604.1',1758788405),(174,12,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 16_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1',1758894493),(175,12,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 16_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1',1758894522),(176,9,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0 Mobile/15E148 Safari/604.1',1758894620),(177,9,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0 Mobile/15E148 Safari/604.1',1758894648),(178,9,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0 Mobile/15E148 Safari/604.1',1758894664),(179,12,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 16_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1',1758894675),(180,12,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 16_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1',1758895139),(181,12,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 16_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1',1758895151),(182,12,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 16_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1',1758895604),(183,12,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 16_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1',1758895686),(184,12,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 16_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1',1759136564),(185,12,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 16_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1',1759136871),(186,14,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759154278),(187,14,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759154289),(188,15,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_1_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1.1 Mobile/15E148 Safari/604.1',1759155162),(189,16,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759155339),(190,14,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759156406),(191,17,'Login successful','150.228.149.210','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759156436),(192,18,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 16_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.3 Mobile/15E148 Safari/604.1',1759156800),(193,17,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759156993),(194,19,'Login successful','150.228.149.210','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759157244),(195,17,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759157260),(196,15,'Login successful','150.228.149.210','Mozilla/5.0 (iPhone; CPU iPhone OS 18_1_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1.1 Mobile/15E148 Safari/604.1',1759157492),(197,15,'Login successful','150.228.149.210','Mozilla/5.0 (iPhone; CPU iPhone OS 18_1_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1.1 Mobile/15E148 Safari/604.1',1759157496),(198,15,'Login successful','150.228.149.210','Mozilla/5.0 (iPhone; CPU iPhone OS 18_1_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1.1 Mobile/15E148 Safari/604.1',1759157499),(199,20,'Login successful','114.131.16.131','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759157512),(200,18,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 16_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.3 Mobile/15E148 Safari/604.1',1759157514),(201,19,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759157777),(202,18,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 16_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.3 Mobile/15E148 Safari/604.1',1759158054),(203,14,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759158368),(204,17,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759158474),(205,15,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_1_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1.1 Mobile/15E148 Safari/604.1',1759158518),(206,18,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 16_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.3 Mobile/15E148 Safari/604.1',1759158552),(207,21,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759158597),(208,21,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759158614),(209,17,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759158615),(210,16,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759158616),(211,22,'Login successful','150.228.149.210','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759158626),(212,16,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759158661),(213,16,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759158666),(214,16,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759158722),(215,21,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759158729),(216,15,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_1_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1.1 Mobile/15E148 Safari/604.1',1759158776),(217,14,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759158877),(218,20,'Login successful','114.131.16.131','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759158984),(219,18,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 16_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.3 Mobile/15E148 Safari/604.1',1759159015),(220,16,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759159031),(221,14,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759159120),(222,20,'Login successful','114.131.16.131','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759159209),(223,17,'Login successful','150.228.149.210','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759159437),(224,17,'Login successful','150.228.149.210','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759159450),(225,17,'Login successful','150.228.149.210','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759159465),(226,17,'Login successful','150.228.149.210','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759159502),(227,16,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759159502),(228,20,'Login successful','114.131.16.131','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759159594),(229,16,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759159604),(230,20,'Login successful','114.131.16.131','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759159611),(231,16,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759159652),(232,17,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759159751),(233,17,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759159813),(234,9,'Login successful','129.224.203.84','Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1',1759215448),(235,9,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0 Mobile/15E148 Safari/604.1',1759288146),(236,14,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759288718),(237,14,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759288731),(238,18,'Login successful','129.224.203.32','Mozilla/5.0 (iPhone; CPU iPhone OS 16_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.3 Mobile/15E148 Safari/604.1',1759289100),(239,16,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759292446),(240,16,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759303312),(241,13,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1 Mobile/15E148 Safari/604.1',1759307865),(242,17,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759326248),(243,17,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759326327),(244,12,'Login successful','129.224.203.32','Mozilla/5.0 (iPhone; CPU iPhone OS 16_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1',1759329109),(245,12,'Login successful','129.224.203.32','Mozilla/5.0 (iPhone; CPU iPhone OS 16_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1',1759329113),(246,12,'Login successful','129.224.203.32','Mozilla/5.0 (iPhone; CPU iPhone OS 16_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1',1759329114),(247,20,'Login successful','114.131.16.131','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759330065),(248,17,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759330375),(249,17,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759330696),(250,17,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759331041),(251,19,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759331465),(252,17,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759332056),(253,17,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759332259),(254,22,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759332282),(255,17,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759332283),(256,16,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759332680),(257,18,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 16_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.3 Mobile/15E148 Safari/604.1',1759369930),(258,12,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 16_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1',1759392854),(259,12,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 16_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1',1759392998),(260,21,'Login successful','129.224.202.131','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759395180),(261,21,'Login successful','129.224.202.131','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759395183),(262,13,'Login successful','114.131.16.133','Mozilla/5.0 (iPhone; CPU iPhone OS 18_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1 Mobile/15E148 Safari/604.1',1759410164),(263,13,'Login successful','114.131.16.133','Mozilla/5.0 (iPhone; CPU iPhone OS 18_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1 Mobile/15E148 Safari/604.1',1759410221),(264,21,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759419247),(265,19,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759420448),(266,18,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 16_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.3 Mobile/15E148 Safari/604.1',1759457086),(267,18,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 16_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.3 Mobile/15E148 Safari/604.1',1759459477),(268,23,'Login successful','150.228.148.22','Mozilla/5.0 (iPhone; CPU iPhone OS 18_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.4 Mobile/15E148 Safari/604.1',1759460937),(269,23,'Login successful','150.228.148.22','Mozilla/5.0 (iPhone; CPU iPhone OS 18_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.4 Mobile/15E148 Safari/604.1',1759460943),(270,23,'Login successful','150.228.148.22','Mozilla/5.0 (iPhone; CPU iPhone OS 18_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.4 Mobile/15E148 Safari/604.1',1759460954),(271,23,'Login successful','150.228.148.22','Mozilla/5.0 (iPhone; CPU iPhone OS 18_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.4 Mobile/15E148 Safari/604.1',1759460963),(272,23,'Login successful','150.228.148.22','Mozilla/5.0 (iPhone; CPU iPhone OS 18_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.4 Mobile/15E148 Safari/604.1',1759460973),(273,23,'Login successful','150.228.148.22','Mozilla/5.0 (iPhone; CPU iPhone OS 18_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.4 Mobile/15E148 Safari/604.1',1759461016),(274,23,'Login successful','150.228.148.22','Mozilla/5.0 (iPhone; CPU iPhone OS 18_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.4 Mobile/15E148 Safari/604.1',1759461750),(275,23,'Login successful','150.228.148.22','Mozilla/5.0 (iPhone; CPU iPhone OS 18_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.4 Mobile/15E148 Safari/604.1',1759461987),(276,23,'Login successful','150.228.148.22','Mozilla/5.0 (iPhone; CPU iPhone OS 18_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.4 Mobile/15E148 Safari/604.1',1759463858),(277,13,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1 Mobile/15E148 Safari/604.1',1759465011),(278,23,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.4 Mobile/15E148 Safari/604.1',1759465739),(279,17,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 17_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.7 Mobile/15E148 Safari/604.1',1759496857),(280,17,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 17_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.7 Mobile/15E148 Safari/604.1',1759497004),(281,17,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 17_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.7 Mobile/15E148 Safari/604.1',1759497006),(282,16,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759802749),(283,16,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759809280),(284,12,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 16_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1',1759836123),(285,24,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 15_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.5 Mobile/15E148 Safari/604.1',1759850075),(286,13,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1 Mobile/15E148 Safari/604.1',1759851896),(287,13,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1 Mobile/15E148 Safari/604.1',1759851959),(288,24,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 15_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.5 Mobile/15E148 Safari/604.1',1759928958),(289,24,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 15_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.5 Mobile/15E148 Safari/604.1',1759928979),(290,17,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 17_5_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1',1759930674),(291,15,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_1_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1.1 Mobile/15E148 Safari/604.1',1759938452),(292,16,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759938520),(293,16,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1759938561),(294,18,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 17_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Mobile/15E148 Safari/604.1',1759938965),(295,12,'Login successful','114.131.16.33','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36',1759976547),(296,12,'Login successful','114.131.16.33','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36',1759976561),(297,12,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.2 Mobile/15E148 Safari/604.1',1759976632),(298,17,'Login successful','157.15.39.205','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36',1759977381),(299,12,'Login successful','150.228.149.44','Mozilla/5.0 (iPhone; CPU iPhone OS 16_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1',1759979302),(300,12,'Login successful','114.131.16.33','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36',1760008501),(301,12,'Login successful','114.131.16.33','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36',1760008510),(302,13,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1 Mobile/15E148 Safari/604.1',1760013027),(303,13,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1 Mobile/15E148 Safari/604.1',1760013064),(304,12,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.2 Mobile/15E148 Safari/604.1',1760014365),(305,13,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1 Mobile/15E148 Safari/604.1',1760023119),(306,17,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1760027081),(307,18,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 17_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Mobile/15E148 Safari/604.1',1760027266),(308,18,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 17_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Mobile/15E148 Safari/604.1',1760027314),(309,24,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 15_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.5 Mobile/15E148 Safari/604.1',1760105829),(310,16,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1760191681),(311,16,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1760193509),(312,13,'Login successful','129.224.202.105','Mozilla/5.0 (iPhone; CPU iPhone OS 18_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1 Mobile/15E148 Safari/604.1',1760280336),(313,25,'Login successful','0.0.0.0','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36',1760282284),(314,26,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 16_1_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.1 Mobile/15E148 Safari/604.1',1760529232),(315,26,'Login successful','0.0.0.0','Mozilla/5.0 (iPhone; CPU iPhone OS 16_1_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.1 Mobile/15E148 Safari/604.1',1760529268),(316,27,'Login successful','0.0.0.0','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36',1760533492),(317,27,'Login successful','0.0.0.0','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36',1760533859),(318,27,'Login successful','0.0.0.0','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36',1760533912),(319,27,'Login successful','0.0.0.0','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36',1760533920),(320,27,'Login successful','123.16.53.194','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36',1760595069),(321,27,'Login successful','0.0.0.0','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36',1760604344),(322,27,'Login successful','0.0.0.0','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36',1760605426),(323,27,'Login successful','0.0.0.0','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36',1760605764),(324,27,'Login successful','0.0.0.0','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36',1760611597),(325,27,'Login successful','0.0.0.0','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36',1760915585),(326,17,'Login successful','103.197.156.7','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1764274982),(327,17,'Login successful','194.5.48.212','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1764287075),(328,17,'Login successful','185.255.126.173','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1764290015),(329,17,'Login successful','194.5.48.132','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1764295390),(330,17,'Login successful','103.197.156.7','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1764321780),(331,17,'Login successful','103.197.156.7','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1764322639),(332,17,'Login successful','103.197.156.7','Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1',1764323449);
/*!40000 ALTER TABLE `wolive_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wolive_admin_menu`
--

DROP TABLE IF EXISTS `wolive_admin_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wolive_admin_menu` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `pid` int(11) NOT NULL DEFAULT '0' COMMENT '父级ID',
  `title` varchar(50) DEFAULT NULL COMMENT '名称',
  `href` varchar(50) NOT NULL COMMENT '地址',
  `icon` varchar(50) DEFAULT NULL COMMENT '图标',
  `sort` tinyint(4) NOT NULL DEFAULT '99' COMMENT '排序',
  `type` tinyint(1) DEFAULT '1' COMMENT '菜单',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `pid` (`pid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='权限表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wolive_admin_menu`
--

LOCK TABLES `wolive_admin_menu` WRITE;
/*!40000 ALTER TABLE `wolive_admin_menu` DISABLE KEYS */;
INSERT INTO `wolive_admin_menu` VALUES (1,0,'首页','/backend/index/home','layui-icon layui-icon-home',1,1,1),(2,0,'登录日志','/backend/log/index','layui-icon layui-icon-layouts',2,1,1),(3,0,'商户管理','','layui-icon layui-icon-username',1,0,1),(4,3,'商户列表','/backend/busines/index',NULL,99,1,1),(5,3,'客服列表','/backend/services/index',NULL,99,1,1);
/*!40000 ALTER TABLE `wolive_admin_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wolive_admin_permission`
--

DROP TABLE IF EXISTS `wolive_admin_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wolive_admin_permission` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `pid` int(11) NOT NULL DEFAULT '0' COMMENT '父级ID',
  `title` varchar(50) DEFAULT NULL COMMENT '名称',
  `href` varchar(50) NOT NULL COMMENT '地址',
  `icon` varchar(50) DEFAULT NULL COMMENT '图标',
  `sort` tinyint(4) NOT NULL DEFAULT '99' COMMENT '排序',
  `type` tinyint(1) DEFAULT '1' COMMENT '菜单',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `is_admin` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否管理员',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `pid` (`pid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='权限表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wolive_admin_permission`
--

LOCK TABLES `wolive_admin_permission` WRITE;
/*!40000 ALTER TABLE `wolive_admin_permission` DISABLE KEYS */;
INSERT INTO `wolive_admin_permission` VALUES (1,0,'首页','/service/index/home','layui-icon layui-icon-home',1,1,1,0),(2,0,'客服管理','','layui-icon layui-icon-username',2,0,1,1),(3,2,'客服列表','/service/services/index',NULL,99,1,1,1),(4,2,'客服分组','/service/groups/index',NULL,99,1,1,1),(5,0,'评价列表','/service/comments/index','layui-icon layui-icon-praise',5,1,1,1),(6,0,'评价设置','/service/comments/setting','layui-icon layui-icon-tabs',6,1,1,1),(7,0,'常见问题设置','/service/questions/index','layui-icon layui-icon-survey',4,1,1,1),(8,0,'客户管理','','layui-icon layui-icon-user',3,0,1,1),(9,8,'客户列表','/service/visitors/index',NULL,99,1,1,1),(10,8,'客户分组','/service/vgroups/index',NULL,99,1,1,1),(11,0,'问候语设置','/service/setting/sentence','layui-icon layui-icon-release',6,1,1,0),(12,0,'消息记录','/service/history/index','layui-icon layui-icon-form',7,1,1,1),(13,0,'客服工作台','/service/chat/index','layui-icon layui-icon-service',1,1,1,0),(14,0,'机器人知识库','/service/robots/index','layui-icon layui-icon-service',4,1,1,1),(15,0,'如何接入','','layui-icon layui-icon-unlink',8,0,1,1),(16,15,'接入配置','/service/setting/access',NULL,99,1,1,1),(17,15,'接入教程','/service/setting/course',NULL,99,1,1,1),(18,0,'商户设置','/service/setting/index','layui-icon layui-icon-set',1,1,1,1),(23,0,'登录日志','/service/log/index','layui-icon layui-icon-layouts',8,1,1,1),(24,0,'数据统计','/service/log/data','layui-icon layui-icon-senior',8,1,1,1),(25,0,'违禁词','/service/banwords/index','layui-icon layui-icon-face-cry',4,1,1,1);
/*!40000 ALTER TABLE `wolive_admin_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wolive_admin_token`
--

DROP TABLE IF EXISTS `wolive_admin_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wolive_admin_token` (
  `token` varchar(50) NOT NULL COMMENT 'Token',
  `user_id` int(11) unsigned NOT NULL DEFAULT '0',
  `createtime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `expiretime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '过期时间',
  PRIMARY KEY (`token`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='Token表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wolive_admin_token`
--

LOCK TABLES `wolive_admin_token` WRITE;
/*!40000 ALTER TABLE `wolive_admin_token` DISABLE KEYS */;
/*!40000 ALTER TABLE `wolive_admin_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wolive_attachment_data`
--

DROP TABLE IF EXISTS `wolive_attachment_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wolive_attachment_data` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '附件id',
  `service_id` int(10) unsigned NOT NULL DEFAULT '0',
  `admin_id` int(10) unsigned NOT NULL DEFAULT '0',
  `filename` varchar(255) NOT NULL DEFAULT '' COMMENT '原文件名',
  `fileext` varchar(20) NOT NULL COMMENT '文件扩展名',
  `filesize` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  `url` varchar(600) NOT NULL DEFAULT '',
  `filemd5` varchar(64) NOT NULL DEFAULT '',
  `inputtime` int(10) unsigned NOT NULL COMMENT '入库时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `inputtime` (`inputtime`) USING BTREE,
  KEY `fileext` (`fileext`) USING BTREE,
  KEY `uid` (`service_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='附件归档表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wolive_attachment_data`
--

LOCK TABLES `wolive_attachment_data` WRITE;
/*!40000 ALTER TABLE `wolive_attachment_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `wolive_attachment_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wolive_banword`
--

DROP TABLE IF EXISTS `wolive_banword`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wolive_banword` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `business_id` int(11) NOT NULL DEFAULT '0',
  `keyword` varchar(255) NOT NULL DEFAULT '' COMMENT '关键词',
  `lang` char(50) NOT NULL DEFAULT 'cn',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '1显示 0不显示',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wolive_banword`
--

LOCK TABLES `wolive_banword` WRITE;
/*!40000 ALTER TABLE `wolive_banword` DISABLE KEYS */;
/*!40000 ALTER TABLE `wolive_banword` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wolive_business`
--

DROP TABLE IF EXISTS `wolive_business`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wolive_business` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `business_name` varchar(100) NOT NULL COMMENT '商家标识符',
  `logo` varchar(255) NOT NULL DEFAULT '',
  `copyright` varchar(255) NOT NULL DEFAULT '' COMMENT '底部版权信息',
  `admin_id` int(11) NOT NULL DEFAULT '0',
  `video_state` enum('close','open') NOT NULL DEFAULT 'close' COMMENT '是否开启视频',
  `voice_state` enum('close','open') NOT NULL DEFAULT 'open' COMMENT '是否开启提示音',
  `audio_state` enum('close','open') NOT NULL DEFAULT 'close' COMMENT '是否开启音频',
  `template_state` enum('close','open') NOT NULL DEFAULT 'close' COMMENT '是否开启模板消息',
  `distribution_rule` enum('auto','claim') DEFAULT 'auto' COMMENT 'claim:认领，auto:自动分配',
  `voice_address` varchar(255) NOT NULL DEFAULT '/upload/voice/default.mp3' COMMENT '提示音文件地址',
  `remark` varchar(255) NOT NULL DEFAULT '',
  `expire_time` int(11) NOT NULL DEFAULT '0',
  `max_count` int(11) NOT NULL DEFAULT '0',
  `push_url` varchar(255) NOT NULL DEFAULT '' COMMENT '推送url',
  `state` enum('close','open') NOT NULL DEFAULT 'open' COMMENT '''open'': 打开该商户 ，‘close’：禁止该商户',
  `is_recycle` tinyint(2) NOT NULL DEFAULT '0',
  `is_delete` tinyint(2) NOT NULL DEFAULT '0',
  `lang` char(50) DEFAULT 'cn',
  `bd_trans_appid` varchar(255) DEFAULT NULL COMMENT '百度翻译APPID',
  `bd_trans_secret` varchar(255) DEFAULT NULL COMMENT '百度翻译密钥',
  `google_trans_key` varchar(255) DEFAULT NULL COMMENT '谷歌翻译KEY',
  `bd_location_ak` varchar(255) DEFAULT NULL COMMENT '百度地图AK',
  `auto_trans` tinyint(1) NOT NULL DEFAULT '0' COMMENT '发送客服是否自动翻译',
  `auto_ip` tinyint(1) NOT NULL DEFAULT '0' COMMENT '根据IP自动设置客户语言',
  `trans_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '翻译接口：百度0；谷歌1',
  `theme` char(50) NOT NULL DEFAULT '13c9cb' COMMENT '主题颜色',
  `header` char(50) NOT NULL DEFAULT '13c9cb' COMMENT '悬浮条背景色',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `bussiness` (`business_name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='商家表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wolive_business`
--

LOCK TABLES `wolive_business` WRITE;
/*!40000 ALTER TABLE `wolive_business` DISABLE KEYS */;
INSERT INTO `wolive_business` VALUES (1,'admin','','',0,'close','open','close','close','auto','/upload/voice/default.mp3','',0,0,'','open',0,0,'en','','','','',0,0,1,'13c9cb','13c9cb');
/*!40000 ALTER TABLE `wolive_business` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wolive_chats`
--

DROP TABLE IF EXISTS `wolive_chats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wolive_chats` (
  `cid` int(11) NOT NULL AUTO_INCREMENT,
  `visiter_id` varchar(200) NOT NULL COMMENT '访客id',
  `service_id` int(11) NOT NULL COMMENT '客服id',
  `business_id` int(11) NOT NULL DEFAULT '0' COMMENT '商家id',
  `content` mediumtext NOT NULL COMMENT '内容',
  `timestamp` int(11) NOT NULL,
  `state` enum('readed','unread') NOT NULL DEFAULT 'unread' COMMENT 'unread 未读；readed 已读',
  `direction` enum('to_visiter','to_service') DEFAULT NULL,
  `unstr` varchar(50) NOT NULL DEFAULT '' COMMENT '前端唯一字符串用于撤销使用',
  `type` tinyint(1) NOT NULL DEFAULT '1',
  `content_trans` mediumtext COMMENT '译文',
  PRIMARY KEY (`cid`) USING BTREE,
  KEY `visiter_id` (`visiter_id`) USING BTREE,
  KEY `service_id` (`service_id`) USING BTREE,
  KEY `business_id` (`business_id`) USING BTREE,
  KEY `unstr` (`unstr`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=51 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='消息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wolive_chats`
--

LOCK TABLES `wolive_chats` WRITE;
/*!40000 ALTER TABLE `wolive_chats` DISABLE KEYS */;
INSERT INTO `wolive_chats` VALUES (1,'68bd4e50v8hn1zeudd6',1,1,'你好',1757236866,'readed','to_service','',1,'你好'),(2,'68bd4e50v8hn1zeudd6',1,1,'1',1757236904,'readed','to_service','',1,'1'),(3,'68bd4e50v8hn1zeudd6',1,1,'222',1757236949,'readed','to_service','',1,'222'),(4,'68bd4e50v8hn1zeudd6',1,1,'123',1757237134,'readed','to_visiter','1757237133124jLFe468bd4e50v8hn1zeudd6',1,NULL),(5,'68bd4e50v8hn1zeudd6',1,1,'123',1757237237,'readed','to_visiter','1757237237429BQrbX68bd4e50v8hn1zeudd6',1,NULL),(6,'68bd4e50v8hn1zeudd6',1,1,'333',1757238556,'readed','to_service','',1,'333'),(7,'68bd4e50v8hn1zeudd6',1,1,'444',1757238636,'readed','to_service','',1,'444'),(8,'68bd4e50v8hn1zeudd6',1,1,'1',1757238721,'readed','to_visiter','1757238720745WkiRD68bd4e50v8hn1zeudd6',1,NULL),(10,'68bd4e50v8hn1zeudd6',1,1,'12',1757241485,'readed','to_service','',1,'12'),(11,'68bd4e50v8hn1zeudd6',1,1,'13',1757241489,'readed','to_service','',1,'13'),(12,'68bd4e50v8hn1zeudd6',1,1,'14',1757241493,'readed','to_visiter','17572414930658DA2i68bd4e50v8hn1zeudd6',1,NULL),(13,'68bd4e50v8hn1zeudd6',1,1,'15',1757241496,'readed','to_visiter','1757241496532WNu7G68bd4e50v8hn1zeudd6',1,NULL),(14,'68bd70aaej5oaa6r1c0',2,1,'1',1757245616,'readed','to_service','',1,'1'),(15,'68bd70aaej5oaa6r1c0',2,1,'12',1757245647,'readed','to_service','',1,'12'),(16,'68bd70aaej5oaa6r1c0',2,1,'13',1757245667,'readed','to_service','',1,'13'),(17,'68bd70aaej5oaa6r1c0',2,1,'14',1757245675,'readed','to_service','',1,'14'),(20,'19',2,1,'11',1757250244,'readed','to_service','',1,'11'),(21,'2',3,1,'你好',1757255227,'readed','to_service','',1,'你好'),(19,'68bd70aaej5oaa6r1c0',2,1,'16',1757245719,'readed','to_service','',1,'16'),(22,'2',3,1,'1',1757255261,'readed','to_visiter','1757255261209oxhSx2',1,NULL),(23,'2',3,1,'seek',1757257241,'readed','to_service','',1,'seek'),(24,'51',3,1,'1',1757260279,'readed','to_service','',1,'1'),(25,'2',5,1,'1',1757260888,'readed','to_visiter','1757260888368UU5P62',1,NULL),(26,'2',1,1,'你好',1757933304,'readed','to_service','',1,'你好'),(27,'2',1,1,'你好',1757933347,'readed','to_visiter','1757933347775jRgGM2',1,NULL),(28,'1',2,1,'1',1758289057,'unread','to_service','',1,'1'),(29,'1',5,1,'1',1758289303,'unread','to_service','',1,'1'),(30,'1',5,1,'1',1758289366,'unread','to_service','',1,'1'),(31,'37',10,1,'1',1758289558,'readed','to_service','',1,'1'),(32,'37',10,1,'1',1758289570,'readed','to_visiter','17582895701711XZLc37',1,NULL),(33,'37',2,1,'1',1758289709,'readed','to_service','',1,'1'),(34,'38',7,1,'1',1758337976,'unread','to_service','',1,'1'),(35,'35',7,1,'1',1758355080,'readed','to_service','',1,'1'),(36,'38',7,1,'1',1758362217,'unread','to_service','',1,'1'),(37,'37',10,1,'nihao ',1758362276,'readed','to_service','',1,'nihao '),(38,'37',10,1,'1',1758362358,'readed','to_visiter','1758362358803sd7E137',1,NULL),(39,'37',10,1,'可以发商品吗',1758362372,'readed','to_service','',1,'可以发商品吗'),(40,'37',7,1,'<img  src=\"/upload/emoji/1f633.png\"> ',1758713058,'unread','to_service','',1,'<img  src=\"/upload/emoji/1f633.png\"> '),(41,'36',9,1,'你好',1758713078,'readed','to_service','',1,'你好'),(42,'36',9,1,'有什么需要帮助吗',1758713118,'readed','to_visiter','1758713118189Ir8lo36',1,NULL),(43,'36',9,1,'你这看书',1758713286,'readed','to_service','',1,'你这看书'),(44,'36',9,1,'1',1758713292,'readed','to_service','',1,'1'),(45,'36',9,1,'今生今世说',1758713296,'readed','to_service','',1,'今生今世说'),(46,'68d3e14e2a3qiwlla98',5,1,'111222',1758716421,'readed','to_service','',1,'111222'),(47,'68d3e14e2a3qiwlla98',5,1,'123',1758716475,'readed','to_service','',1,'123'),(48,'68d3e14e2a3qiwlla98',5,1,'q',1758716513,'readed','to_visiter','1758716514097iUVW568d3e14e2a3qiwlla98',1,NULL),(49,'68d3e14e2a3qiwlla98',5,1,'好的\n',1758716521,'readed','to_service','',1,'好的\n'),(50,'37',7,1,'1',1758718884,'unread','to_service','',1,'1');
/*!40000 ALTER TABLE `wolive_chats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wolive_comment`
--

DROP TABLE IF EXISTS `wolive_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wolive_comment` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(11) NOT NULL DEFAULT '0',
  `service_id` int(11) NOT NULL DEFAULT '0',
  `group_id` int(11) NOT NULL DEFAULT '0',
  `visiter_id` varchar(200) NOT NULL DEFAULT '',
  `visiter_name` varchar(255) NOT NULL DEFAULT '',
  `word_comment` text NOT NULL COMMENT '文字评价',
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wolive_comment`
--

LOCK TABLES `wolive_comment` WRITE;
/*!40000 ALTER TABLE `wolive_comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `wolive_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wolive_comment_detail`
--

DROP TABLE IF EXISTS `wolive_comment_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wolive_comment_detail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` int(11) unsigned NOT NULL,
  `title` varchar(32) NOT NULL DEFAULT '',
  `score` tinyint(4) NOT NULL DEFAULT '1' COMMENT '分数',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wolive_comment_detail`
--

LOCK TABLES `wolive_comment_detail` WRITE;
/*!40000 ALTER TABLE `wolive_comment_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `wolive_comment_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wolive_comment_setting`
--

DROP TABLE IF EXISTS `wolive_comment_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wolive_comment_setting` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(11) NOT NULL DEFAULT '0',
  `title` varchar(128) NOT NULL DEFAULT '' COMMENT '评价说明',
  `comments` text NOT NULL COMMENT '评价条目',
  `word_switch` enum('close','open') NOT NULL DEFAULT 'close',
  `word_title` varchar(32) NOT NULL DEFAULT '',
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wolive_comment_setting`
--

LOCK TABLES `wolive_comment_setting` WRITE;
/*!40000 ALTER TABLE `wolive_comment_setting` DISABLE KEYS */;
/*!40000 ALTER TABLE `wolive_comment_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wolive_group`
--

DROP TABLE IF EXISTS `wolive_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wolive_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupname` varchar(255) DEFAULT NULL,
  `business_id` int(11) unsigned NOT NULL DEFAULT '0',
  `sort` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` int(11) DEFAULT NULL COMMENT '操作时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wolive_group`
--

LOCK TABLES `wolive_group` WRITE;
/*!40000 ALTER TABLE `wolive_group` DISABLE KEYS */;
INSERT INTO `wolive_group` VALUES (1,'tiktok',1,0,1757245534);
/*!40000 ALTER TABLE `wolive_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wolive_message`
--

DROP TABLE IF EXISTS `wolive_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wolive_message` (
  `mid` int(11) NOT NULL AUTO_INCREMENT,
  `content` text NOT NULL COMMENT '留言内容',
  `name` varchar(255) NOT NULL COMMENT '留言人姓名',
  `moblie` varchar(255) NOT NULL COMMENT '留言人电话',
  `email` varchar(255) NOT NULL COMMENT '留言人邮箱',
  `business_id` int(11) DEFAULT '0',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`mid`) USING BTREE,
  KEY `timestamp` (`timestamp`) USING BTREE,
  KEY `web` (`business_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wolive_message`
--

LOCK TABLES `wolive_message` WRITE;
/*!40000 ALTER TABLE `wolive_message` DISABLE KEYS */;
/*!40000 ALTER TABLE `wolive_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wolive_option`
--

DROP TABLE IF EXISTS `wolive_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wolive_option` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `business_id` int(11) NOT NULL DEFAULT '0',
  `group` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL,
  `value` longtext NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `business_id` (`business_id`) USING BTREE,
  KEY `group` (`group`) USING BTREE,
  KEY `name` (`title`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wolive_option`
--

LOCK TABLES `wolive_option` WRITE;
/*!40000 ALTER TABLE `wolive_option` DISABLE KEYS */;
/*!40000 ALTER TABLE `wolive_option` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wolive_question`
--

DROP TABLE IF EXISTS `wolive_question`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wolive_question` (
  `qid` int(11) NOT NULL AUTO_INCREMENT,
  `business_id` int(11) NOT NULL DEFAULT '0',
  `question` longtext NOT NULL,
  `keyword` varchar(12) NOT NULL DEFAULT '' COMMENT '关键词',
  `sort` int(11) NOT NULL DEFAULT '0',
  `answer` longtext NOT NULL,
  `answer_read` longtext NOT NULL,
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '1显示 0不显示',
  `lang` char(50) NOT NULL DEFAULT 'cn',
  PRIMARY KEY (`qid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='常见问题表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wolive_question`
--

LOCK TABLES `wolive_question` WRITE;
/*!40000 ALTER TABLE `wolive_question` DISABLE KEYS */;
/*!40000 ALTER TABLE `wolive_question` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wolive_queue`
--

DROP TABLE IF EXISTS `wolive_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wolive_queue` (
  `qid` int(11) NOT NULL AUTO_INCREMENT,
  `visiter_id` varchar(200) NOT NULL COMMENT '访客id',
  `service_id` int(11) NOT NULL COMMENT '客服id',
  `groupid` int(11) DEFAULT '0' COMMENT '客服分类id',
  `business_id` int(11) NOT NULL DEFAULT '0',
  `state` enum('normal','complete','in_black_list') NOT NULL DEFAULT 'normal' COMMENT 'normal：正常接入,‘complete’:已经解决，‘in_black_list’:黑名单',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `remind_tpl` tinyint(2) NOT NULL DEFAULT '0' COMMENT '是否已发送模板消息',
  `remind_comment` tinyint(2) NOT NULL DEFAULT '0' COMMENT '是否已推送评价',
  PRIMARY KEY (`qid`) USING BTREE,
  KEY `se` (`service_id`) USING BTREE,
  KEY `vi` (`visiter_id`) USING BTREE,
  KEY `business` (`business_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='会话表(排队表)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wolive_queue`
--

LOCK TABLES `wolive_queue` WRITE;
/*!40000 ALTER TABLE `wolive_queue` DISABLE KEYS */;
INSERT INTO `wolive_queue` VALUES (1,'68bbb99dsuz2up1law3',8,0,1,'normal','2025-09-24 12:15:53',0,0),(2,'68bd4e50v8hn1zeudd6',1,0,1,'complete','2025-09-24 12:20:54',0,0),(3,'68bd70aaej5oaa6r1c0',2,1,1,'normal','2025-09-07 11:46:50',0,0),(4,'19',2,0,1,'normal','2025-09-07 13:03:49',0,0),(5,'2',1,0,1,'complete','2025-09-24 12:20:51',0,0),(6,'50',1,0,1,'complete','2025-09-24 12:21:02',0,0),(7,'68bda47e87izhxfld38',4,0,1,'normal','2025-09-07 15:38:42',0,0),(8,'51',3,0,1,'normal','2025-09-07 15:51:06',0,0),(9,'68be5899scb6e9v8a75',1,0,1,'complete','2025-09-24 12:20:55',0,0),(10,'68bf9a1820e8vbphyb8',3,0,1,'normal','2025-09-09 03:08:14',0,0),(11,'68c1133ftk83ag6vaq9',4,0,1,'normal','2025-09-10 05:57:21',0,0),(12,'68c30e63lueqj66lld7',5,0,1,'normal','2025-09-11 18:01:15',0,0),(13,'68c7b2d3bzkjuk9fp07',1,0,1,'complete','2025-09-24 12:21:02',0,0),(14,'68c7b2dfp96fd1xd3v9',1,0,1,'complete','2025-09-24 12:21:01',0,0),(15,'68c7b2e2mr92gkmi0d2',1,0,1,'complete','2025-09-24 12:21:01',0,0),(16,'68c7b2e59qujwdlf2n5',1,0,1,'complete','2025-09-24 12:21:00',0,0),(17,'68c7b31c9h61h8audp0',1,0,1,'complete','2025-09-24 12:21:00',0,0),(18,'68c7b39cm1hxn0vkli8',1,0,1,'complete','2025-09-24 12:20:59',0,0),(19,'68c7b3b11d1oxjs5219',1,0,1,'complete','2025-09-24 12:20:58',0,0),(20,'68c7b3bewi1kyz44mt2',1,0,1,'complete','2025-09-24 12:20:57',0,0),(21,'68c7b3d97j5x16vgx79',1,0,1,'complete','2025-09-24 12:20:57',0,0),(22,'68c7b4beys3h9v8em48',1,0,1,'complete','2025-09-24 12:20:56',0,0),(23,'68c7b4c2jn47z00zir2',1,0,1,'complete','2025-09-24 12:20:56',0,0),(24,'68c7c15bhlm6g253vp7',1,0,1,'complete','2025-09-24 12:20:55',0,0),(25,'68c90015239z2awtvo1',6,0,1,'normal','2025-09-16 06:13:42',0,0),(26,'68c90efbxh6ll0tqb35',5,0,1,'normal','2025-09-16 07:17:19',0,0),(27,'68c922c8180pztftrb4',6,0,1,'normal','2025-09-16 08:41:44',0,0),(28,'68c9700fevr81i6l587',2,0,1,'normal','2025-09-16 14:11:28',0,0),(29,'53',6,0,1,'normal','2025-09-18 14:19:23',0,0),(30,'55',3,0,1,'normal','2025-09-19 12:24:37',0,0),(31,'1',5,0,1,'normal','2025-09-19 13:42:43',0,0),(32,'57',3,0,1,'normal','2025-09-19 13:21:56',0,0),(33,'37',7,0,1,'normal','2025-09-24 11:24:13',0,0),(34,'38',7,0,1,'normal','2025-09-20 09:56:32',0,0),(35,'35',11,0,1,'normal','2025-09-20 08:32:03',0,0),(36,'36',9,0,1,'normal','2025-09-24 11:24:33',0,0),(37,'68d3e14e2a3qiwlla98',5,1,1,'normal','2025-09-24 12:17:18',0,0),(38,'71',16,0,1,'normal','2025-10-11 16:44:26',0,0);
/*!40000 ALTER TABLE `wolive_queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wolive_reply`
--

DROP TABLE IF EXISTS `wolive_reply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wolive_reply` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `word` varchar(255) DEFAULT NULL,
  `service_id` int(11) DEFAULT NULL,
  `tag` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wolive_reply`
--

LOCK TABLES `wolive_reply` WRITE;
/*!40000 ALTER TABLE `wolive_reply` DISABLE KEYS */;
/*!40000 ALTER TABLE `wolive_reply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wolive_rest_setting`
--

DROP TABLE IF EXISTS `wolive_rest_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wolive_rest_setting` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(11) NOT NULL DEFAULT '0',
  `state` enum('open','close') NOT NULL DEFAULT 'open',
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `week` varchar(32) NOT NULL DEFAULT '',
  `reply` varchar(255) NOT NULL DEFAULT '',
  `name_state` enum('open','close') NOT NULL DEFAULT 'open',
  `tel_state` enum('open','close') NOT NULL DEFAULT 'open',
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wolive_rest_setting`
--

LOCK TABLES `wolive_rest_setting` WRITE;
/*!40000 ALTER TABLE `wolive_rest_setting` DISABLE KEYS */;
/*!40000 ALTER TABLE `wolive_rest_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wolive_robot`
--

DROP TABLE IF EXISTS `wolive_robot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wolive_robot` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `business_id` int(11) NOT NULL DEFAULT '0',
  `keyword` varchar(12) NOT NULL DEFAULT '' COMMENT '关键词',
  `sort` int(11) NOT NULL DEFAULT '0',
  `reply` longtext NOT NULL,
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '1显示 0不显示',
  `lang` char(50) NOT NULL DEFAULT 'cn',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='常见问题表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wolive_robot`
--

LOCK TABLES `wolive_robot` WRITE;
/*!40000 ALTER TABLE `wolive_robot` DISABLE KEYS */;
/*!40000 ALTER TABLE `wolive_robot` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wolive_sentence`
--

DROP TABLE IF EXISTS `wolive_sentence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wolive_sentence` (
  `sid` int(11) NOT NULL AUTO_INCREMENT,
  `content` text NOT NULL COMMENT '内容',
  `service_id` int(11) NOT NULL COMMENT '所属客服id',
  `state` enum('using','unuse') NOT NULL DEFAULT 'using' COMMENT 'unuse: 未使用 ，using：使用中',
  `lang` char(50) NOT NULL DEFAULT 'cn',
  PRIMARY KEY (`sid`) USING BTREE,
  KEY `se` (`service_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wolive_sentence`
--

LOCK TABLES `wolive_sentence` WRITE;
/*!40000 ALTER TABLE `wolive_sentence` DISABLE KEYS */;
/*!40000 ALTER TABLE `wolive_sentence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wolive_service`
--

DROP TABLE IF EXISTS `wolive_service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wolive_service` (
  `service_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(255) NOT NULL COMMENT '用户名',
  `nick_name` varchar(255) NOT NULL COMMENT '昵称',
  `password` varchar(255) NOT NULL COMMENT '密码',
  `groupid` varchar(225) DEFAULT '0' COMMENT '客服分类id',
  `phone` varchar(255) DEFAULT '' COMMENT '手机',
  `open_id` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(255) DEFAULT '' COMMENT '邮箱',
  `business_id` int(11) NOT NULL DEFAULT '0',
  `avatar` varchar(1024) NOT NULL DEFAULT '/assets/images/admin/avatar-admin2.png' COMMENT '头像',
  `level` enum('super_manager','manager','service') NOT NULL DEFAULT 'service' COMMENT 'super_manager: 超级管理员，manager：商家管理员 ，service：普通客服',
  `parent_id` int(11) NOT NULL DEFAULT '0' COMMENT '所属商家管理员id',
  `offline_first` tinyint(2) NOT NULL DEFAULT '0',
  `state` enum('online','offline') NOT NULL DEFAULT 'offline' COMMENT 'online：在线，offline：离线',
  PRIMARY KEY (`service_id`) USING BTREE,
  UNIQUE KEY `user_name` (`user_name`) USING BTREE,
  KEY `pid` (`parent_id`) USING BTREE,
  KEY `web` (`business_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='后台客服表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wolive_service`
--

LOCK TABLES `wolive_service` WRITE;
/*!40000 ALTER TABLE `wolive_service` DISABLE KEYS */;
INSERT INTO `wolive_service` VALUES (1,'admin','客服小美','d8f7c2d2775869fb69b8757edcf6ae4f','0','','','',1,'/assets/images/admin/avatar-admin2.png','super_manager',0,0,'offline'),(2,'13111111111','13111111111','41ec2b316b83a3146ee4b769dec16962','1','13111111111','123456','',1,'/assets/images/admin/avatar-admin2.png','service',1,0,'online'),(3,'13012345678','seek','19c812beed6fc7fd085818d3174fe0f6','1','13012345678','123456','',1,'/assets/images/admin/avatar-admin2.png','service',1,0,'online'),(4,'15852477010','Why doesn\'t anyone buy my stuff?','a7d8fc28c3a2c29c1d11d934dbd94689','1','15852477010','123456','',1,'/assets/images/admin/avatar-admin2.png','service',1,0,'online'),(5,'15111111111','测试店铺','fe91b97eb4db31d1b1bf678fd7efbca6','1','15111111111','123456','',1,'/assets/images/admin/avatar-admin2.png','service',1,0,'offline'),(6,'16111111111','demoa','1e0faa8d582b07f4080406bef73e8c5d','1','16111111111','123456','',1,'/assets/images/admin/avatar-admin2.png','service',1,0,'online'),(7,'18361191111','Tiktok','8b9ea1b3b3a0c97f9f595d84458fc3aa','1','18361191111','123456','',1,'/assets/images/admin/avatar-admin2.png','service',1,0,'online'),(8,'13888888888','lztest','946e0a937e4737d754bec5bb8bd500e6','1','13888888888','123456','',1,'/assets/images/admin/avatar-admin2.png','service',1,0,'offline'),(9,'87788600','NextPick','8bdd2183d7ea1617a205647844261c7e','1','87788600','123456','',1,'/assets/images/admin/avatar-admin2.png','service',1,0,'offline'),(10,'23243242','test1','4e587aa0fb07e391a050493a1896a653','1','23243242','123456','',1,'/assets/images/admin/avatar-admin2.png','service',1,0,'offline'),(11,'66778899','潮品店','1f630e2a8b82654346c4ffe5454c083b','1','66778899','123456','',1,'/assets/images/admin/avatar-admin2.png','service',1,0,'offline'),(12,'0987678111','HomeNest Shop','bce576ffc3688a89d68c5eac5ab3e31f','1','0987678111','123456','',1,'/assets/images/admin/avatar-admin2.png','service',1,0,'online'),(13,'012345678','Shop Smart','162d53be1014fcdc34e442154abf7dda','1','012345678','123456','',1,'/assets/images/admin/avatar-admin2.png','service',1,0,'offline'),(14,'0335653262','Ginzmun Shop','de52dbea04ad2b0dce13c8c59666d6af','1','0335653262','123456','',1,'/assets/images/admin/avatar-admin2.png','service',1,0,'online'),(15,'0333533423','Fast Shop','27740f7bbae05fd8159be9773e06ab72','1','0333533423','123456','',1,'/assets/images/admin/avatar-admin2.png','service',1,0,'offline'),(16,'0913638479','Sammi Shop','6a5a67fd40ce9cb5446b52825da1a061','1','0913638479','123456','',1,'/assets/images/admin/avatar-admin2.png','service',1,0,'online'),(17,'868118286','ASANZO','0634900d3bea3518044c99cc6881c6e2','1','868118286','123456','',1,'/assets/images/admin/avatar-admin2.png','service',1,0,'offline'),(18,'0968332456','COMPANY','98c0a3298c55d855d295e40457d8e82f','1','0968332456','123456','',1,'/assets/images/admin/avatar-admin2.png','service',1,0,'online'),(19,'988551724','ECO MARKET','a38ab5ef8845b96ec0ba54c8dbf774fd','1','988551724','123456','',1,'/assets/images/admin/avatar-admin2.png','service',1,0,'offline'),(20,'852522874','NEW HOME','aa219eff134bc3770a05d3efb3ea3fb8','1','852522874','123456','',1,'/assets/images/admin/avatar-admin2.png','service',1,0,'online'),(21,'393511314','Leo Store T.O.P','d7bbd38df4ca03ddc7bdda2f5a55b85e','1','393511314','123456','',1,'/assets/images/admin/avatar-admin2.png','service',1,0,'offline'),(22,'0847251768','NẤM SHOP','6923ba6b86c9bc3447b879a894c6d366','1','0847251768','123456','',1,'/assets/images/admin/avatar-admin2.png','service',1,0,'offline'),(23,'1231231231','，alukou','1ef39a8a7719a4446dda035c8531ddb9','1','1231231231','123456','',1,'/assets/images/admin/avatar-admin2.png','service',1,0,'online'),(24,'0963882599','Hoa mai','9ea154e2b7810e4579280bf959984f49','1','0963882599','123456','',1,'/assets/images/admin/avatar-admin2.png','service',1,0,'online'),(25,'964978074','Angel shop','a28efb7dbf9326cb15b109589315e4ce','1','964978074','123456','',1,'/assets/images/admin/avatar-admin2.png','service',1,0,'offline'),(26,'923135135','orion shop','435ab9791beacefcf21933e73c2fbac9','1','923135135','123456','',1,'/assets/images/admin/avatar-admin2.png','service',1,0,'offline'),(27,'0823933413','Ebay Thanhtroy','c5898ea2d56b5a386b65877e40b1e94a','1','0823933413','123456','',1,'/assets/images/admin/avatar-admin2.png','service',1,0,'offline');
/*!40000 ALTER TABLE `wolive_service` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wolive_storage`
--

DROP TABLE IF EXISTS `wolive_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wolive_storage` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `admin_id` int(11) NOT NULL,
  `type` tinyint(1) NOT NULL COMMENT '存储类型：1=本地，2=阿里云，3=腾讯云，4=七牛',
  `config` text CHARACTER SET utf8mb4 NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wolive_storage`
--

LOCK TABLES `wolive_storage` WRITE;
/*!40000 ALTER TABLE `wolive_storage` DISABLE KEYS */;
/*!40000 ALTER TABLE `wolive_storage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wolive_tablist`
--

DROP TABLE IF EXISTS `wolive_tablist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wolive_tablist` (
  `tid` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL COMMENT 'tab的名称',
  `content_read` text,
  `content` text NOT NULL,
  `business_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`tid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wolive_tablist`
--

LOCK TABLES `wolive_tablist` WRITE;
/*!40000 ALTER TABLE `wolive_tablist` DISABLE KEYS */;
/*!40000 ALTER TABLE `wolive_tablist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wolive_vgroup`
--

DROP TABLE IF EXISTS `wolive_vgroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wolive_vgroup` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(11) NOT NULL DEFAULT '0',
  `service_id` int(11) NOT NULL DEFAULT '0',
  `group_name` varchar(128) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `bgcolor` char(7) NOT NULL DEFAULT '#707070',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wolive_vgroup`
--

LOCK TABLES `wolive_vgroup` WRITE;
/*!40000 ALTER TABLE `wolive_vgroup` DISABLE KEYS */;
/*!40000 ALTER TABLE `wolive_vgroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wolive_visiter`
--

DROP TABLE IF EXISTS `wolive_visiter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wolive_visiter` (
  `vid` int(11) NOT NULL AUTO_INCREMENT,
  `visiter_id` varchar(200) NOT NULL COMMENT '访客id',
  `visiter_name` varchar(255) NOT NULL COMMENT '访客名称',
  `channel` varchar(255) NOT NULL COMMENT '用户游客频道',
  `avatar` varchar(1024) NOT NULL COMMENT '头像',
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT '用户自己填写的姓名',
  `tel` varchar(32) NOT NULL DEFAULT '' COMMENT '用户自己填写的电话',
  `login_times` int(11) NOT NULL DEFAULT '1' COMMENT '登录次数',
  `connect` text COMMENT '联系方式',
  `comment` text COMMENT '备注',
  `extends` text COMMENT '浏览器扩展',
  `ip` varchar(255) NOT NULL COMMENT '访客ip',
  `from_url` varchar(255) NOT NULL COMMENT '访客浏览地址',
  `msg_time` timestamp NULL DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '访问时间',
  `business_id` int(11) NOT NULL DEFAULT '0',
  `state` enum('online','offline') NOT NULL DEFAULT 'offline' COMMENT 'offline：离线，online：在线',
  `istop` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '1置顶展示0未置顶',
  `lang` char(255) NOT NULL DEFAULT 'cn',
  PRIMARY KEY (`vid`) USING BTREE,
  UNIQUE KEY `id` (`visiter_id`,`business_id`) USING BTREE,
  KEY `visiter` (`visiter_id`) USING BTREE,
  KEY `time` (`timestamp`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wolive_visiter`
--

LOCK TABLES `wolive_visiter` WRITE;
/*!40000 ALTER TABLE `wolive_visiter` DISABLE KEYS */;
INSERT INTO `wolive_visiter` VALUES (1,'68bbb99dsuz2up1law3','游客68bbb99dsuz2up1law3','363862626239396473757a327570316c6177332f31','/assets/images/index/avatar-red2.png','','',11,NULL,NULL,'{\"browserName\":\"\\u8c37\\u6b4c\\u6d4f\\u89c8\\u5668\",\"browserVersion\":\"139.0\",\"os\":\"\\u5fae\\u8f6fWindows\\u7cfb\\u7edf\",\"engine\":\"webkit\"}','138.199.25.98','https://kf.shop110.top/index/index/welcome',NULL,'2025-09-24 12:15:59',1,'offline',0,'cn'),(2,'68bd4e50v8hn1zeudd6','游客68bd4e50v8hn1zeudd6','36386264346535307638686e317a65756464362f31','/assets/images/index/avatar-red2.png','','',2,NULL,NULL,'{\"browserName\":\"\\u8c37\\u6b4c\\u6d4f\\u89c8\\u5668\",\"browserVersion\":\"139.0\",\"os\":\"\\u5fae\\u8f6fWindows\\u7cfb\\u7edf\",\"engine\":\"webkit\"}','138.199.25.98','',NULL,'2025-09-07 09:20:46',1,'online',0,'cn'),(3,'68bd70aaej5oaa6r1c0','游客68bd70aaej5oaa6r1c0','3638626437306161656a356f616136723163302f31','/assets/images/index/avatar-red2.png','','',4,NULL,NULL,'{\"browserName\":\"\\u8c37\\u6b4c\\u6d4f\\u89c8\\u5668\",\"browserVersion\":\"139.0\",\"os\":\"\\u5fae\\u8f6fWindows\\u7cfb\\u7edf\",\"engine\":\"webkit\"}','138.199.25.98','',NULL,'2025-09-07 11:49:02',1,'online',0,'cn'),(4,'19','ZHANGSAN','31392f31','https://demo.shop110.top/uploads/20240609/804606254bf49b96c3db7d2962fb3333.png','','',1,NULL,NULL,'{\"browserName\":\"android\",\"browserVersion\":\"4.3\",\"os\":\"\\u5b89\\u5353\\u7cfb\\u7edf\",\"engine\":\"webkit\"}','138.199.25.98','https://shops.shop110.top/',NULL,'2025-09-07 13:03:49',1,'offline',0,'cn'),(5,'2','游客2','322f31','/assets/images/index/avatar-red2.png','','',17,NULL,NULL,'{\"browserName\":\"android\",\"browserVersion\":\"4.3\",\"os\":\"\\u5b89\\u5353\\u7cfb\\u7edf\",\"engine\":\"webkit\"}','138.199.25.98','https://web.shop110.top/',NULL,'2025-09-15 14:11:07',1,'online',0,'cn'),(6,'50','测试姓名','35302f31','https://demo.shop110.top/uploads/20250907/e3b3312eaf9441baab2f81d6b842a79d.jpg','','',26,NULL,NULL,'{\"browserName\":\"android\",\"browserVersion\":\"4.3\",\"os\":\"\\u5b89\\u5353\\u7cfb\\u7edf\",\"engine\":\"webkit\"}','138.199.25.98','https://shops.shop110.top/',NULL,'2025-09-20 08:43:27',1,'offline',0,'cn'),(7,'68bda47e87izhxfld38','游客68bda47e87izhxfld38','36386264613437653837697a6878666c6433382f31','/assets/images/index/avatar-red2.png','','',2,NULL,NULL,'{\"browserName\":\"\\u8c37\\u6b4c\\u6d4f\\u89c8\\u5668\",\"browserVersion\":\"138.0\",\"os\":\"MAC\\u7cfb\\u7edf\",\"engine\":\"webkit\"}','118.143.88.196','https://kf.shop110.top/index/index/welcome.html',NULL,'2025-09-07 15:38:42',1,'online',0,'cn'),(8,'51','le','35312f31','https://demo.shop110.top/uploads/20250907/43e5bcbafc3a034076a7761bed5991cf.png','','',7,NULL,NULL,'{\"browserName\":\"Safari\\u6d4f\\u89c8\\u5668\",\"browserVersion\":\"16.6\",\"os\":\"\\u82f9\\u679c\\u624b\\u673a\\u7cfb\\u7edf\",\"engine\":\"webkit\"}','103.169.127.202','https://shops.shop110.top/',NULL,'2025-09-19 12:04:38',1,'online',0,'vi'),(9,'68be5899scb6e9v8a75','游客68be5899scb6e9v8a75','363862653538393973636236653976386137352f31','/assets/images/index/avatar-red2.png','','',11,NULL,NULL,'{\"browserName\":\"Safari\\u6d4f\\u89c8\\u5668\",\"browserVersion\":\"18.6\",\"os\":\"\\u82f9\\u679c\\u624b\\u673a\\u7cfb\\u7edf\",\"engine\":\"webkit\"}','150.228.148.150','https://web.shop110.top/',NULL,'2025-09-16 03:42:03',1,'online',0,'vi'),(10,'68bf9a1820e8vbphyb8','游客68bf9a1820e8vbphyb8','363862663961313832306538766270687962382f31','/assets/images/index/avatar-red2.png','','',1,NULL,NULL,'{\"browserName\":\"\\u8c37\\u6b4c\\u6d4f\\u89c8\\u5668\",\"browserVersion\":\"92.0\",\"os\":\"\\u5fae\\u8f6fWindows\\u7cfb\\u7edf\",\"engine\":\"webkit\"}','36.99.136.140','http://kf.shop110.top/index/index/welcome',NULL,'2025-09-09 03:08:14',1,'offline',0,'cn'),(11,'68c1133ftk83ag6vaq9','游客68c1133ftk83ag6vaq9','3638633131333366746b3833616736766171392f31','/assets/images/index/avatar-red2.png','','',1,NULL,NULL,'{\"browserName\":\"\\u8c37\\u6b4c\\u6d4f\\u89c8\\u5668\",\"browserVersion\":\"92.0\",\"os\":\"\\u5fae\\u8f6fWindows\\u7cfb\\u7edf\",\"engine\":\"webkit\"}','36.99.136.139','http://kf.shop110.top/index/index/price',NULL,'2025-09-10 05:57:21',1,'offline',0,'cn'),(12,'68c30e63lueqj66lld7','游客68c30e63lueqj66lld7','36386333306536336c7565716a36366c6c64372f31','/assets/images/index/avatar-red2.png','','',1,NULL,NULL,'{\"browserName\":\"\\u8c37\\u6b4c\\u6d4f\\u89c8\\u5668\",\"browserVersion\":\"124.0\",\"os\":\"\\u5fae\\u8f6fWindows\\u7cfb\\u7edf\",\"engine\":\"webkit\"}','110.87.249.130','https://kf.shop110.top/index/index/welcome',NULL,'2025-09-11 18:01:15',1,'offline',0,'cn'),(13,'68c7b2d3bzkjuk9fp07','游客68c7b2d3bzkjuk9fp07','3638633762326433627a6b6a756b39667030372f31','/assets/images/index/avatar-red2.png','','',1,NULL,NULL,'{\"browserName\":\"android\",\"browserVersion\":\"4.3\",\"os\":\"\\u5b89\\u5353\\u7cfb\\u7edf\",\"engine\":\"webkit\"}','138.199.25.98','http://localhost:5173/',NULL,'2025-09-15 06:31:48',1,'offline',0,'cn'),(14,'68c7b2dfp96fd1xd3v9','游客68c7b2dfp96fd1xd3v9','363863376232646670393666643178643376392f31','/assets/images/index/avatar-red2.png','','',1,NULL,NULL,'{\"browserName\":\"android\",\"browserVersion\":\"4.3\",\"os\":\"\\u5b89\\u5353\\u7cfb\\u7edf\",\"engine\":\"webkit\"}','138.199.25.98','http://localhost:5173/',NULL,'2025-09-15 06:31:59',1,'offline',0,'cn'),(15,'68c7b2e2mr92gkmi0d2','游客68c7b2e2mr92gkmi0d2','36386337623265326d723932676b6d693064322f31','/assets/images/index/avatar-red2.png','','',1,NULL,NULL,'{\"browserName\":\"android\",\"browserVersion\":\"4.3\",\"os\":\"\\u5b89\\u5353\\u7cfb\\u7edf\",\"engine\":\"webkit\"}','138.199.25.98','http://localhost:5173/',NULL,'2025-09-15 06:32:02',1,'offline',0,'cn'),(16,'68c7b2e59qujwdlf2n5','游客68c7b2e59qujwdlf2n5','36386337623265353971756a77646c66326e352f31','/assets/images/index/avatar-red2.png','','',1,NULL,NULL,'{\"browserName\":\"android\",\"browserVersion\":\"4.3\",\"os\":\"\\u5b89\\u5353\\u7cfb\\u7edf\",\"engine\":\"webkit\"}','138.199.25.98','http://localhost:5173/',NULL,'2025-09-15 06:32:06',1,'offline',0,'cn'),(17,'68c7b31c9h61h8audp0','游客68c7b31c9h61h8audp0','363863376233316339683631683861756470302f31','/assets/images/index/avatar-red2.png','','',1,NULL,NULL,'{\"browserName\":\"android\",\"browserVersion\":\"4.3\",\"os\":\"\\u5b89\\u5353\\u7cfb\\u7edf\",\"engine\":\"webkit\"}','138.199.25.98','http://localhost:5173/',NULL,'2025-09-15 06:33:01',1,'offline',0,'cn'),(18,'68c7b39cm1hxn0vkli8','游客68c7b39cm1hxn0vkli8','36386337623339636d3168786e30766b6c69382f31','/assets/images/index/avatar-red2.png','','',1,NULL,NULL,'{\"browserName\":\"android\",\"browserVersion\":\"4.3\",\"os\":\"\\u5b89\\u5353\\u7cfb\\u7edf\",\"engine\":\"webkit\"}','138.199.25.98','http://localhost:5173/',NULL,'2025-09-15 06:35:09',1,'offline',0,'cn'),(19,'68c7b3b11d1oxjs5219','游客68c7b3b11d1oxjs5219','36386337623362313164316f786a73353231392f31','/assets/images/index/avatar-red2.png','','',1,NULL,NULL,'{\"browserName\":\"android\",\"browserVersion\":\"4.3\",\"os\":\"\\u5b89\\u5353\\u7cfb\\u7edf\",\"engine\":\"webkit\"}','138.199.25.98','http://localhost:5173/',NULL,'2025-09-15 06:35:30',1,'offline',0,'cn'),(20,'68c7b3bewi1kyz44mt2','游客68c7b3bewi1kyz44mt2','36386337623362657769316b797a34346d74322f31','/assets/images/index/avatar-red2.png','','',1,NULL,NULL,'{\"browserName\":\"android\",\"browserVersion\":\"4.3\",\"os\":\"\\u5b89\\u5353\\u7cfb\\u7edf\",\"engine\":\"webkit\"}','138.199.25.98','http://localhost:5173/',NULL,'2025-09-15 06:35:42',1,'offline',0,'cn'),(21,'68c7b3d97j5x16vgx79','游客68c7b3d97j5x16vgx79','3638633762336439376a3578313676677837392f31','/assets/images/index/avatar-red2.png','','',1,NULL,NULL,'{\"browserName\":\"android\",\"browserVersion\":\"4.3\",\"os\":\"\\u5b89\\u5353\\u7cfb\\u7edf\",\"engine\":\"webkit\"}','138.199.25.98','http://localhost:5173/',NULL,'2025-09-15 06:36:10',1,'offline',0,'cn'),(22,'68c7b4beys3h9v8em48','游客68c7b4beys3h9v8em48','363863376234626579733368397638656d34382f31','/assets/images/index/avatar-red2.png','','',1,NULL,NULL,'{\"browserName\":\"android\",\"browserVersion\":\"4.3\",\"os\":\"\\u5b89\\u5353\\u7cfb\\u7edf\",\"engine\":\"webkit\"}','138.199.25.98','http://localhost:5173/',NULL,'2025-09-15 06:39:58',1,'offline',0,'cn'),(23,'68c7b4c2jn47z00zir2','游客68c7b4c2jn47z00zir2','36386337623463326a6e34377a30307a6972322f31','/assets/images/index/avatar-red2.png','','',1,NULL,NULL,'{\"browserName\":\"android\",\"browserVersion\":\"4.3\",\"os\":\"\\u5b89\\u5353\\u7cfb\\u7edf\",\"engine\":\"webkit\"}','138.199.25.98','http://localhost:5173/',NULL,'2025-09-15 06:40:03',1,'offline',0,'cn'),(24,'68c7c15bhlm6g253vp7','游客68c7c15bhlm6g253vp7','3638633763313562686c6d36673235337670372f31','/assets/images/index/avatar-red2.png','','',3,NULL,NULL,'{\"browserName\":\"Safari\\u6d4f\\u89c8\\u5668\",\"browserVersion\":\"18.6\",\"os\":\"\\u82f9\\u679c\\u624b\\u673a\\u7cfb\\u7edf\",\"engine\":\"webkit\"}','129.224.202.26','https://web.shop110.top/',NULL,'2025-09-15 13:23:49',1,'online',0,'vi'),(25,'2','yuanze','322f','https://demo.shop110.top/assets/img/avatar.png','','',4,NULL,NULL,'{\"browserName\":\"\\u8c37\\u6b4c\\u6d4f\\u89c8\\u5668\",\"browserVersion\":\"140.0\",\"os\":\"\\u5fae\\u8f6fWindows\\u7cfb\\u7edf\",\"engine\":\"webkit\"}','138.199.25.98','',NULL,'2025-09-15 15:39:19',0,'online',0,'cn'),(26,'68c90015239z2awtvo1','游客68c90015239z2awtvo1','36386339303031353233397a32617774766f312f31','/assets/images/index/avatar-red2.png','','',1,NULL,NULL,'{\"browserName\":\"\\u8c37\\u6b4c\\u6d4f\\u89c8\\u5668\",\"browserVersion\":\"117.0\",\"os\":\"\\u5fae\\u8f6fWindows\\u7cfb\\u7edf\",\"engine\":\"webkit\"}','205.169.39.23','https://kefu.wholesaletiktok.com/index/index/welcome',NULL,'2025-09-16 06:13:42',1,'offline',0,'cn'),(27,'68c90efbxh6ll0tqb35','游客68c90efbxh6ll0tqb35','36386339306566627868366c6c3074716233352f31','/assets/images/index/avatar-red2.png','','',1,NULL,NULL,'{\"browserName\":\"\\u8c37\\u6b4c\\u6d4f\\u89c8\\u5668\",\"browserVersion\":\"119.0\",\"os\":\"Linux\\u7cfb\\u7edf\",\"engine\":\"webkit\"}','149.57.180.78','https://kefu.wholesaletiktok.com/index/index/welcome',NULL,'2025-09-16 07:17:19',1,'offline',0,'cn'),(28,'68c922c8180pztftrb4','游客68c922c8180pztftrb4','3638633932326338313830707a7466747262342f31','/assets/images/index/avatar-red2.png','','',1,NULL,NULL,'{\"browserName\":\"\\u8c37\\u6b4c\\u6d4f\\u89c8\\u5668\",\"browserVersion\":\"140.0\",\"os\":\"MAC\\u7cfb\\u7edf\",\"engine\":\"webkit\"}','150.228.149.149','https://kefu.wholesaletiktok.com/index/index/welcome',NULL,'2025-09-16 08:41:52',1,'offline',0,'cn'),(29,'68c9700fevr81i6l587','游客68c9700fevr81i6l587','3638633937303066657672383169366c3538372f31','/assets/images/index/avatar-red2.png','','',1,NULL,NULL,'{\"browserName\":\"\\u706b\\u72d0\\u6d4f\\u89c8\\u5668\",\"browserVersion\":\"109.0\",\"os\":\"\\u5fae\\u8f6fWindows\\u7cfb\\u7edf\",\"engine\":\"gecko\"}','34.220.82.194','https://kefu.wholesaletiktok.com/index/index/welcome',NULL,'2025-09-16 14:11:28',1,'offline',0,'en'),(30,'53','陈伟霆','35332f31','https://adminsup.shoptittokvn.top/uploads/20250916/bcfe43635dedf3dafd30e3028009d58a.jpeg','','',2,NULL,NULL,'{\"browserName\":\"Safari\\u6d4f\\u89c8\\u5668\",\"browserVersion\":\"18.6\",\"os\":\"\\u82f9\\u679c\\u624b\\u673a\\u7cfb\\u7edf\",\"engine\":\"webkit\"}','0.0.0.0','https://www.wholesaletiktok.com/',NULL,'2025-09-18 14:19:23',1,'online',0,'en'),(31,'55','cdsaf','35352f31','https://aappii.apittkk.com/uploads/20250919/308092afffabfaef474c26bbf04197ff.jpg','','',1,NULL,NULL,'{\"browserName\":\"Safari\\u6d4f\\u89c8\\u5668\",\"browserVersion\":\"18.5\",\"os\":\"\\u82f9\\u679c\\u624b\\u673a\\u7cfb\\u7edf\",\"engine\":\"webkit\"}','150.228.149.196','https://www.wholesaletiktok.com/',NULL,'2025-09-19 12:24:37',1,'offline',0,'en'),(32,'1','admin','312f31','https://aappii.apittkk.com/assets/img/avatar.png','','',9,NULL,NULL,'{\"browserName\":\"Safari\\u6d4f\\u89c8\\u5668\",\"browserVersion\":\"18.6\",\"os\":\"\\u82f9\\u679c\\u624b\\u673a\\u7cfb\\u7edf\",\"engine\":\"webkit\"}','0.0.0.0','https://www.wholesaletiktok.com/',NULL,'2025-09-19 13:45:26',1,'offline',0,'en'),(33,'57','陈家宝','35372f31','https://aappii.apittkk.com/uploads/20250919/00f6b43d726313c9c64c85da3ead5b4a.jpeg','','',2,NULL,NULL,'{\"browserName\":\"Safari\\u6d4f\\u89c8\\u5668\",\"browserVersion\":\"18.6\",\"os\":\"\\u82f9\\u679c\\u624b\\u673a\\u7cfb\\u7edf\",\"engine\":\"webkit\"}','0.0.0.0','https://www.wholesaletiktok.com/',NULL,'2025-09-19 13:22:01',1,'offline',0,'en'),(34,'1','admin','312f','https://aappii.apittkk.com/assets/img/avatar.png','','',3,NULL,NULL,'{\"browserName\":\"Safari\\u6d4f\\u89c8\\u5668\",\"browserVersion\":\"18.6\",\"os\":\"\\u82f9\\u679c\\u624b\\u673a\\u7cfb\\u7edf\",\"engine\":\"webkit\"}','0.0.0.0','https://www.vnmalltiktok.com/',NULL,'2025-09-19 13:41:20',0,'online',0,'en'),(35,'37','ces','33372f31','https://adminsup.shoptittokvn.top/uploads/20250916/f4ed8b396e74f81bba28f78eaa39e0b6.png','','',9,NULL,NULL,'{\"browserName\":\"Safari\\u6d4f\\u89c8\\u5668\",\"browserVersion\":\"18.5\",\"os\":\"\\u82f9\\u679c\\u624b\\u673a\\u7cfb\\u7edf\",\"engine\":\"webkit\"}','150.228.149.196','https://www.vnmalltiktok.com/',NULL,'2025-09-24 13:02:10',1,'offline',0,'en'),(36,'38','世','33382f31','data:image/svg xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZlcnNpb249IjEuMSIgaGVpZ2h0PSIxMDAiIHdpZHRoPSIxMDAiPjxyZWN0IGZpbGw9InJnYigyMjksMTkyLDE2MCkiIHg9IjAiIHk9IjAiIHdpZHRoPSIxMDAiIGhlaWdodD0iMTAwIj48L3JlY3Q PHRleHQgeD0iNTAiIHk9IjUwIiBmb250LXNpemU9IjUwIiB0ZXh0LWNvcHk9ImZhc3QiIGZpbGw9IiNmZmZmZmYiIHRleHQtYW5jaG9yPSJtaWRkbGUiIHRleHQtcmlnaHRzPSJhZG1pbiIgZG9taW5hbnQtYmFzZWxpbmU9ImNlbnRyYWwiPuS4ljwvdGV4dD48L3N2Zz4=','','',4,NULL,NULL,'{\"browserName\":\"AppleWebkit\\u5185\\u6838\\u6d4f\\u89c8\\u5668\",\"browserVersion\":\"605.1\",\"os\":\"\\u82f9\\u679c\\u624b\\u673a\\u7cfb\\u7edf\",\"engine\":\"webkit\"}','0.0.0.0','https://www.ttiomcsa.shop/',NULL,'2025-09-20 09:57:03',1,'online',0,'en'),(37,'35','aaaa','33352f31','data:image/svg xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZlcnNpb249IjEuMSIgaGVpZ2h0PSIxMDAiIHdpZHRoPSIxMDAiPjxyZWN0IGZpbGw9InJnYigyMDksMTYwLDIyOSkiIHg9IjAiIHk9IjAiIHdpZHRoPSIxMDAiIGhlaWdodD0iMTAwIj48L3JlY3Q PHRleHQgeD0iNTAiIHk9IjUwIiBmb250LXNpemU9IjUwIiB0ZXh0LWNvcHk9ImZhc3QiIGZpbGw9IiNmZmZmZmYiIHRleHQtYW5jaG9yPSJtaWRkbGUiIHRleHQtcmlnaHRzPSJhZG1pbiIgZG9taW5hbnQtYmFzZWxpbmU9ImNlbnRyYWwiPkE8L3RleHQ PC9zdmc','','',12,NULL,NULL,'{\"browserName\":\"android\",\"browserVersion\":\"4.3\",\"os\":\"\\u5b89\\u5353\\u7cfb\\u7edf\",\"engine\":\"webkit\"}','138.199.25.98','https://www.vnmalltiktok.com/',NULL,'2025-09-20 08:34:54',1,'offline',0,'en'),(38,'36','ssss','33362f31','data:image/svg xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZlcnNpb249IjEuMSIgaGVpZ2h0PSIxMDAiIHdpZHRoPSIxMDAiPjxyZWN0IGZpbGw9InJnYigxNjAsMjI3LDIyOSkiIHg9IjAiIHk9IjAiIHdpZHRoPSIxMDAiIGhlaWdodD0iMTAwIj48L3JlY3Q PHRleHQgeD0iNTAiIHk9IjUwIiBmb250LXNpemU9IjUwIiB0ZXh0LWNvcHk9ImZhc3QiIGZpbGw9IiNmZmZmZmYiIHRleHQtYW5jaG9yPSJtaWRkbGUiIHRleHQtcmlnaHRzPSJhZG1pbiIgZG9taW5hbnQtYmFzZWxpbmU9ImNlbnRyYWwiPlM8L3RleHQ PC9zdmc','','',4,NULL,NULL,'{\"browserName\":\"Safari\\u6d4f\\u89c8\\u5668\",\"browserVersion\":\"17.7\",\"os\":\"\\u82f9\\u679c\\u624b\\u673a\\u7cfb\\u7edf\",\"engine\":\"webkit\"}','114.131.16.107','https://www.ttiomcsa.shop/',NULL,'2025-09-24 11:28:30',1,'offline',0,'cn'),(39,'68d3e14e2a3qiwlla98','游客68d3e14e2a3qiwlla98','36386433653134653261337169776c6c6139382f31','/assets/images/index/avatar-red2.png','','',2,NULL,NULL,'{\"browserName\":\"\\u8c37\\u6b4c\\u6d4f\\u89c8\\u5668\",\"browserVersion\":\"140.0\",\"os\":\"\\u5fae\\u8f6fWindows\\u7cfb\\u7edf\",\"engine\":\"webkit\"}','138.199.25.98','',NULL,'2025-09-24 12:22:08',1,'offline',0,'en'),(40,'71','Thanh luyen','37312f31','data:image/svg xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZlcnNpb249IjEuMSIgaGVpZ2h0PSIxMDAiIHdpZHRoPSIxMDAiPjxyZWN0IGZpbGw9InJnYigyMDYsMTYwLDIyOSkiIHg9IjAiIHk9IjAiIHdpZHRoPSIxMDAiIGhlaWdodD0iMTAwIj48L3JlY3Q PHRleHQgeD0iNTAiIHk9IjUwIiBmb250LXNpemU9IjUwIiB0ZXh0LWNvcHk9ImZhc3QiIGZpbGw9IiNmZmZmZmYiIHRleHQtYW5jaG9yPSJtaWRkbGUiIHRleHQtcmlnaHRzPSJhZG1pbiIgZG9taW5hbnQtYmFzZWxpbmU9ImNlbnRyYWwiPlQ8L3RleHQ PC9zdmc','','',2,NULL,NULL,'{\"browserName\":\"android\",\"browserVersion\":\"mozilla\\/5.0 (linux; android 15; cph2699 build\\/ap3a.240617.008;) applewebkit\\/537.36 (khtml, like gecko) version\\/4.0 chrome\\/140.0.7339.207 mobile safari\\/537.36 zalo android\\/25092848 zalotheme\\/light zalolanguage\\/vi\",\"os\":\"\\u5b89\\u5353\\u7cfb\\u7edf\",\"engine\":\"webkit\"}','0.0.0.0','https://www.tinnbsm.com/',NULL,'2025-10-11 16:45:17',1,'offline',0,'en');
/*!40000 ALTER TABLE `wolive_visiter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wolive_visiter_vgroup`
--

DROP TABLE IF EXISTS `wolive_visiter_vgroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wolive_visiter_vgroup` (
  `vid` int(11) NOT NULL,
  `business_id` int(11) NOT NULL DEFAULT '0',
  `service_id` int(11) NOT NULL DEFAULT '0',
  `group_id` int(11) NOT NULL DEFAULT '0',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`vid`,`group_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wolive_visiter_vgroup`
--

LOCK TABLES `wolive_visiter_vgroup` WRITE;
/*!40000 ALTER TABLE `wolive_visiter_vgroup` DISABLE KEYS */;
/*!40000 ALTER TABLE `wolive_visiter_vgroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wolive_wechat_platform`
--

DROP TABLE IF EXISTS `wolive_wechat_platform`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wolive_wechat_platform` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `business_id` int(11) NOT NULL DEFAULT '0' COMMENT '客服系统id',
  `wx_id` varchar(60) NOT NULL DEFAULT '' COMMENT '公众号原始id',
  `app_id` varchar(255) NOT NULL DEFAULT '' COMMENT '公众号appid',
  `app_secret` varchar(255) NOT NULL DEFAULT '' COMMENT '公众号appsecret',
  `wx_token` varchar(120) NOT NULL DEFAULT '' COMMENT '公众号token',
  `wx_aeskey` varchar(120) NOT NULL DEFAULT '' COMMENT '消息加解密密钥(EncodingAESKey)',
  `visitor_tpl` varchar(255) NOT NULL DEFAULT '' COMMENT '新访客模板消息',
  `msg_tpl` varchar(255) NOT NULL DEFAULT '' COMMENT '新消息提示模板消息',
  `customer_tpl` varchar(255) NOT NULL DEFAULT '' COMMENT '访客模板消息',
  `isscribe` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否开启引导关注1开启0关闭',
  `desc` varchar(255) NOT NULL COMMENT '公共号说明、备注',
  `addtime` int(11) NOT NULL DEFAULT '0',
  `is_delete` smallint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `business_id` (`business_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='微信公众号';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wolive_wechat_platform`
--

LOCK TABLES `wolive_wechat_platform` WRITE;
/*!40000 ALTER TABLE `wolive_wechat_platform` DISABLE KEYS */;
INSERT INTO `wolive_wechat_platform` VALUES (1,1,'','','','','','','','',0,'无',1758012563,0);
/*!40000 ALTER TABLE `wolive_wechat_platform` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wolive_weixin`
--

DROP TABLE IF EXISTS `wolive_weixin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wolive_weixin` (
  `wid` int(11) NOT NULL AUTO_INCREMENT,
  `business_id` int(11) NOT NULL COMMENT '商户ID',
  `app_id` varchar(64) NOT NULL DEFAULT '' COMMENT '公众号appid',
  `open_id` varchar(255) NOT NULL COMMENT '微信用户id',
  `subscribe` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否关注微信0未关注1已关注',
  `subscribe_time` int(11) NOT NULL DEFAULT '0' COMMENT '关注时间',
  PRIMARY KEY (`wid`) USING BTREE,
  KEY `business_id` (`business_id`) USING BTREE,
  KEY `app_id` (`app_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wolive_weixin`
--

LOCK TABLES `wolive_weixin` WRITE;
/*!40000 ALTER TABLE `wolive_weixin` DISABLE KEYS */;
/*!40000 ALTER TABLE `wolive_weixin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'kefu_wholesaleti'
--

--
-- Dumping routines for database 'kefu_wholesaleti'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-13 20:27:57
